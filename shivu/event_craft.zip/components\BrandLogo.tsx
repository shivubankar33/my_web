import React from "react";
import Link from "next/link";

interface BrandLogoProps {
  size?: "sm" | "md" | "lg";
  showTagline?: boolean;
  className?: string;
}

export default function BrandLogo({
  size = "md",
  showTagline = true,
  className = "",
}: BrandLogoProps) {
  const iconSizes = {
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-12 h-12",
  };

  const textSizes = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-2xl sm:text-3xl",
  };

  return (
    <Link href="/" className={`inline-flex items-center gap-2.5 group ${className}`}>
      {/* Dynamic EventCraft Symbol */}
      <div
        className={`${iconSizes[size]} relative rounded-2xl bg-gradient-to-tr from-brand-700 via-indigo-600 to-amber-500 p-[1.5px] shadow-lg shadow-brand-500/25 group-hover:shadow-brand-500/40 group-hover:scale-105 transition-all duration-300`}
      >
        <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center overflow-hidden relative">
          {/* Subtle background glow */}
          <div className="absolute inset-0 bg-gradient-to-br from-brand-600/30 to-amber-500/20 opacity-80" />

          {/* SVG Symbol: Architectural Venue Stage + Craft Star */}
          <svg
            viewBox="0 0 36 36"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-6 h-6 z-10 drop-shadow-[0_2px_8px_rgba(245,158,11,0.5)] group-hover:rotate-6 transition-transform duration-300"
          >
            {/* Stage Foundation Polygon */}
            <path
              d="M18 4L31 11.5V24.5L18 32L5 24.5V11.5L18 4Z"
              stroke="url(#ecGrad)"
              strokeWidth="2"
              strokeLinejoin="round"
            />
            {/* Inner Pavilion Ribs / Pillars */}
            <path
              d="M18 4V18M31 11.5L18 18M5 11.5L18 18M18 18V32"
              stroke="url(#ecAccent)"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeDasharray="1 1.5"
            />
            {/* Central Radiant Craft Star / Sparkle */}
            <path
              d="M18 11L19.5 15.5L24 17L19.5 18.5L18 23L16.5 18.5L12 17L16.5 15.5L18 11Z"
              fill="url(#starGrad)"
            />
            <circle cx="18" cy="17" r="1.5" fill="#fff" />
            <defs>
              <linearGradient id="ecGrad" x1="5" y1="4" x2="31" y2="32" gradientUnits="userSpaceOnUse">
                <stop stopColor="#c084fc" />
                <stop offset="0.5" stopColor="#6366f1" />
                <stop offset="1" stopColor="#f59e0b" />
              </linearGradient>
              <linearGradient id="ecAccent" x1="5" y1="4" x2="31" y2="32" gradientUnits="userSpaceOnUse">
                <stop stopColor="#e879f9" />
                <stop offset="1" stopColor="#38bdf8" />
              </linearGradient>
              <linearGradient id="starGrad" x1="12" y1="11" x2="24" y2="23" gradientUnits="userSpaceOnUse">
                <stop stopColor="#fbbf24" />
                <stop offset="1" stopColor="#f59e0b" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>

      {/* Brand Text */}
      <div className="flex flex-col text-left">
        <div className="flex items-center gap-1.5">
          <span
            className={`font-black ${textSizes[size]} tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-slate-900 via-brand-600 to-indigo-600 dark:from-white dark:via-brand-400 dark:to-amber-300 leading-none`}
          >
            EventCraft
          </span>
          <span className="px-1.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-widest bg-gradient-to-r from-amber-500/20 to-brand-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30">
            PRO
          </span>
        </div>
        {showTagline && (
          <span className="text-[10px] tracking-wider uppercase font-bold text-slate-500 dark:text-slate-400 mt-0.5">
            Architectural Event Platform
          </span>
        )}
      </div>
    </Link>
  );
}
