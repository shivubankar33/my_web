"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { User, UserRole } from "@/types";
import { useToast } from "@/components/Toast";

interface RegisterData {
  name: string;
  email: string;
  phone: string;
  password?: string;
  role: "host" | "client";
}

interface AuthContextType {
  user: User | null;
  role: UserRole;
  isAuthenticated: boolean;
  login: (email: string, password?: string, explicitRole?: UserRole) => boolean;
  register: (data: RegisterData) => boolean;
  logout: () => void;
  loginQuick: (targetRole: "host" | "client") => void;
}

const AUTH_STORAGE_KEY = "eventcraft_auth_user";

export const DEMO_CLIENT: User = {
  id: "u-client-demo",
  name: "Sarah Jenkins",
  email: "sarah.j@eventplanner.io",
  phone: "+1 (555) 349-8812",
  role: "client",
  avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80",
};

export const DEMO_HOST: User = {
  id: "u-host-demo",
  name: "Marcus Vance",
  email: "marcus.v@premierestates.com",
  phone: "+1 (555) 890-4321",
  role: "host",
  avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80",
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const { showToast } = useToast();

  useEffect(() => {
    try {
      const stored = localStorage.getItem(AUTH_STORAGE_KEY);
      if (stored) {
        setUser(JSON.parse(stored));
      }
    } catch (e) {
      console.error("Failed to load auth user from localStorage", e);
    }
  }, []);

  const login = (email: string, password?: string, explicitRole?: UserRole): boolean => {
    // Simulated credential check
    let resolvedRole: UserRole = explicitRole || "client";
    if (email.toLowerCase().includes("host") || email.toLowerCase().includes("admin")) {
      resolvedRole = "host";
    }

    const matchedUser: User =
      resolvedRole === "host"
        ? { ...DEMO_HOST, email }
        : { ...DEMO_CLIENT, email };

    setUser(matchedUser);
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(matchedUser));
    showToast(`Welcome back, ${matchedUser.name}! Logged in as ${resolvedRole.toUpperCase()}.`, "success");
    return true;
  };

  const register = (data: RegisterData): boolean => {
    const newUser: User = {
      id: `u-${Date.now()}`,
      name: data.name,
      email: data.email,
      phone: data.phone,
      role: data.role,
      avatar:
        data.role === "host"
          ? "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
          : "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
      createdAt: new Date().toISOString(),
    };

    setUser(newUser);
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(newUser));
    showToast(`Account created successfully! Welcome, ${newUser.name}.`, "success");
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(AUTH_STORAGE_KEY);
    showToast("You have been signed out successfully.", "info");
  };

  const loginQuick = (targetRole: "host" | "client") => {
    const targetUser = targetRole === "host" ? DEMO_HOST : DEMO_CLIENT;
    setUser(targetUser);
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(targetUser));
    showToast(
      `Fast-Switched to ${targetRole === "host" ? "Host (Marcus Vance)" : "Client (Sarah Jenkins)"}`,
      "success"
    );
  };

  const role: UserRole = user?.role || "guest";
  const isAuthenticated = !!user;

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        isAuthenticated,
        login,
        register,
        logout,
        loginQuick,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
