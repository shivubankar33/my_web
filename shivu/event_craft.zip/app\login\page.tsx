"use client";

import React, { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useAuth } from "@/lib/authContext";
import { useToast } from "@/components/Toast";
import BrandLogo from "@/components/BrandLogo";
import VenueBuildingAnimation from "@/components/VenueBuildingAnimation";
import {
  Lock,
  Mail,
  User,
  Phone,
  Building2,
  CalendarHeart,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Zap,
  Sparkles,
} from "lucide-react";

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { login, register, loginQuick, isAuthenticated, role } = useAuth();
  const { showToast } = useToast();

  const [mode, setMode] = useState<"login" | "register">("login");
  const [selectedRole, setSelectedRole] = useState<"host" | "client">("client");

  // Form Fields
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    const roleParam = searchParams.get("role");
    if (roleParam === "host") {
      setSelectedRole("host");
      setMode("register");
    }
  }, [searchParams]);

  // Client-side Validation
  const validateForm = () => {
    const errs: Record<string, string> = {};

    if (!email.trim()) {
      errs.email = "Email address is required.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      errs.email = "Please enter a valid email address.";
    }

    if (!password) {
      errs.password = "Password is required.";
    } else if (password.length < 6) {
      errs.password = "Password must be at least 6 characters.";
    }

    if (mode === "register") {
      if (!name.trim()) {
        errs.name = "Full name is required.";
      }
      if (!phone.trim()) {
        errs.phone = "Phone number is required.";
      } else if (!/^[+0-9\s\-()]{7,20}$/.test(phone)) {
        errs.phone = "Please enter a valid phone number.";
      }
      if (password !== confirmPassword) {
        errs.confirmPassword = "Passwords do not match.";
      }
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    if (mode === "login") {
      const ok = login(email, password);
      if (ok) {
        const dest = email.toLowerCase().includes("host") ? "/admin" : "/plan-event";
        router.push(dest);
      }
    } else {
      const ok = register({
        name,
        email,
        phone,
        password,
        role: selectedRole,
      });
      if (ok) {
        router.push(selectedRole === "host" ? "/admin" : "/plan-event");
      }
    }
  };

  const handleQuickSwitch = (target: "host" | "client") => {
    loginQuick(target);
    if (target === "host") {
      router.push("/admin");
    } else {
      router.push("/plan-event");
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-8 px-4 sm:px-6 lg:px-8 bg-slate-50 dark:bg-slate-950 transition-colors">
      <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* LEFT COLUMN: Animated Venue Crafting Cartoon & Building Visual */}
        <div className="lg:col-span-6 flex flex-col justify-center">
          <div className="mb-4 text-left">
            <BrandLogo size="lg" />
            <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white mt-3">
              Watch an Event Venue Come to Life
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              From hardwood foundations to crystal chandeliers and botanical floral arches, craft every detail with EventCraft.
            </p>
          </div>

          {/* Interactive Cartoon Venue Building Animation */}
          <VenueBuildingAnimation />
        </div>

        {/* RIGHT COLUMN: Modern Auth Form Card */}
        <div className="lg:col-span-6 flex flex-col justify-center space-y-4">
          {/* Quick Dev Switcher Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-brand-950/80 to-purple-950/80 border border-brand-500/30 text-white shadow-lg backdrop-blur-md">
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Instant Developer Testing</span>
              </div>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-white/10 text-slate-300">
                1-Click Auth
              </span>
            </div>
            <p className="text-[11px] text-slate-300 mb-3">
              Switch roles immediately to test client-side planner or host estate management:
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickSwitch("client")}
                className="px-3 py-2 rounded-xl text-xs font-bold bg-white text-slate-900 hover:bg-slate-100 flex items-center justify-center gap-1.5 shadow-sm transition-transform active:scale-95"
              >
                <CalendarHeart className="w-3.5 h-3.5 text-brand-600" />
                <span>Login as Client</span>
              </button>
              <button
                type="button"
                onClick={() => handleQuickSwitch("host")}
                className="px-3 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center justify-center gap-1.5 shadow-sm transition-transform active:scale-95"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-slate-950" />
                <span>Login as Host</span>
              </button>
            </div>
          </div>

          {/* Card Container */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-xl">
            {/* Header */}
            <div className="text-left mb-6">
              <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">
                {mode === "login" ? "Welcome back to EventCraft" : "Create Your EventCraft Account"}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                {mode === "login"
                  ? "Enter your credentials to manage your bookings and custom venue packages"
                  : "Join EventCraft to begin planning or hosting extraordinary celebrations"}
              </p>
            </div>

            {/* Mode Switcher Tabs */}
            <div className="grid grid-cols-2 p-1 rounded-xl bg-slate-100 dark:bg-slate-800/80 mb-6">
              <button
                type="button"
                onClick={() => setMode("login")}
                className={`py-2 text-xs font-bold rounded-lg transition-all ${
                  mode === "login"
                    ? "bg-white dark:bg-slate-900 text-brand-600 dark:text-brand-400 shadow-sm"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white"
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => setMode("register")}
                className={`py-2 text-xs font-bold rounded-lg transition-all ${
                  mode === "register"
                    ? "bg-white dark:bg-slate-900 text-brand-600 dark:text-brand-400 shadow-sm"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white"
                }`}
              >
                Register
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Role Selection on Register */}
              {mode === "register" && (
                <div className="space-y-2">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Select Your EventCraft Role
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setSelectedRole("client")}
                      className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                        selectedRole === "client"
                          ? "border-brand-500 bg-brand-50/50 dark:bg-brand-950/40 text-brand-900 dark:text-brand-200 ring-2 ring-brand-500/20"
                          : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <CalendarHeart className="w-5 h-5 text-brand-500" />
                        {selectedRole === "client" && (
                          <CheckCircle2 className="w-4 h-4 text-brand-600 dark:text-brand-400" />
                        )}
                      </div>
                      <div>
                        <p className="text-xs font-bold">Client / Planner</p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                          Craft events & book venues
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setSelectedRole("host")}
                      className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                        selectedRole === "host"
                          ? "border-amber-500 bg-amber-50/50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 ring-2 ring-amber-500/20"
                          : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <Building2 className="w-5 h-5 text-amber-500" />
                        {selectedRole === "host" && (
                          <CheckCircle2 className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                        )}
                      </div>
                      <div>
                        <p className="text-xs font-bold">Event Host</p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                          List spaces & approve bookings
                        </p>
                      </div>
                    </button>
                  </div>
                </div>
              )}

              {/* Full Name (Register only) */}
              {mode === "register" && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Full Name
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Jessica Sterling"
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500 transition-colors"
                    />
                  </div>
                  {errors.name && <p className="text-[11px] text-rose-500 mt-1">{errors.name}</p>}
                </div>
              )}

              {/* Email Address */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@eventcraft.io"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500 transition-colors"
                  />
                </div>
                {errors.email && <p className="text-[11px] text-rose-500 mt-1">{errors.email}</p>}
              </div>

              {/* Phone Number (Register only) */}
              {mode === "register" && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Phone Number
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+1 (555) 000-0000"
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500 transition-colors"
                    />
                  </div>
                  {errors.phone && <p className="text-[11px] text-rose-500 mt-1">{errors.phone}</p>}
                </div>
              )}

              {/* Password */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500 transition-colors"
                  />
                </div>
                {errors.password && <p className="text-[11px] text-rose-500 mt-1">{errors.password}</p>}
              </div>

              {/* Confirm Password (Register only) */}
              {mode === "register" && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500 transition-colors"
                    />
                  </div>
                  {errors.confirmPassword && (
                    <p className="text-[11px] text-rose-500 mt-1">{errors.confirmPassword}</p>
                  )}
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full mt-2 py-3.5 px-4 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-brand-600 via-indigo-600 to-purple-600 hover:from-brand-500 hover:to-purple-500 shadow-lg shadow-brand-500/25 hover:shadow-brand-500/40 hover:scale-[1.01] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <span>{mode === "login" ? "Sign In to EventCraft" : "Complete Registration"}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center">
          <p className="text-sm font-semibold text-brand-500">Loading EventCraft Auth...</p>
        </div>
      }
    >
      <LoginForm />
    </Suspense>
  );
}
