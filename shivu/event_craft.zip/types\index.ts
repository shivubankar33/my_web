export type UserRole = "host" | "client" | "guest";

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar?: string;
  createdAt?: string;
}

export interface Venue {
  id: string;
  title: string;
  image: string;
  capacity: number;
  pricePerHour: number;
  location: string;
  description: string;
  tags: string[];
  rating?: number;
  amenities?: string[];
}

export interface Decoration {
  id: string;
  title: string;
  image: string;
  category: string;
  baselinePrice: number;
  description: string;
  includedItems?: string[];
}

export interface AddOnService {
  id: string;
  name: string;
  price: number;
  unit: "flat" | "per_guest";
  description: string;
  iconName: string;
}

export type BookingStatus = "pending" | "approved" | "rejected";

export interface Booking {
  id: string;
  userId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  venueId: string;
  decorationId: string;
  guestCount: number;
  date: string;
  time: string;
  durationHours: number;
  addOns: string[];
  totalBudget: number;
  status: BookingStatus;
  createdAt: string;
  notes?: string;
}

export interface CostBreakdown {
  venueCost: number;
  decorationCost: number;
  addOnsCost: number;
  serviceFee: number;
  total: number;
}
