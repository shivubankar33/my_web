import { Venue, Decoration, Booking, BookingStatus } from "@/types";
import { initialVenues, initialDecorations, initialBookings } from "@/data/mockData";

const VENUES_KEY = "eventcraft_venues";
const DECORATIONS_KEY = "eventcraft_decorations";
const BOOKINGS_KEY = "eventcraft_bookings";
export const STORAGE_CHANGE_EVENT = "eventcraft_storage_updated";

function isClient(): boolean {
  return typeof window !== "undefined";
}

function notifyStorageChange() {
  if (isClient()) {
    window.dispatchEvent(new Event(STORAGE_CHANGE_EVENT));
  }
}

// ------------------- VENUES -------------------

export function getVenues(): Venue[] {
  if (!isClient()) return initialVenues;
  try {
    const raw = localStorage.getItem(VENUES_KEY);
    if (!raw) {
      localStorage.setItem(VENUES_KEY, JSON.stringify(initialVenues));
      return initialVenues;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error("Error reading venues from localStorage", e);
    return initialVenues;
  }
}

export function saveVenues(venues: Venue[]): void {
  if (!isClient()) return;
  try {
    localStorage.setItem(VENUES_KEY, JSON.stringify(venues));
    notifyStorageChange();
  } catch (e) {
    console.error("Error saving venues to localStorage", e);
  }
}

export function addVenue(venueData: Omit<Venue, "id">): Venue {
  const venues = getVenues();
  const newVenue: Venue = {
    ...venueData,
    id: `v-${Date.now()}`,
    rating: venueData.rating || 5.0,
  };
  saveVenues([newVenue, ...venues]);
  return newVenue;
}

export function updateVenue(venue: Venue): Venue {
  const venues = getVenues();
  const updated = venues.map((v) => (v.id === venue.id ? venue : v));
  saveVenues(updated);
  return venue;
}

export function deleteVenue(id: string): void {
  const venues = getVenues();
  const updated = venues.filter((v) => v.id !== id);
  saveVenues(updated);
}

// ------------------- DECORATIONS -------------------

export function getDecorations(): Decoration[] {
  if (!isClient()) return initialDecorations;
  try {
    const raw = localStorage.getItem(DECORATIONS_KEY);
    if (!raw) {
      localStorage.setItem(DECORATIONS_KEY, JSON.stringify(initialDecorations));
      return initialDecorations;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error("Error reading decorations from localStorage", e);
    return initialDecorations;
  }
}

export function saveDecorations(decorations: Decoration[]): void {
  if (!isClient()) return;
  try {
    localStorage.setItem(DECORATIONS_KEY, JSON.stringify(decorations));
    notifyStorageChange();
  } catch (e) {
    console.error("Error saving decorations to localStorage", e);
  }
}

export function addDecoration(decorData: Omit<Decoration, "id">): Decoration {
  const decorations = getDecorations();
  const newDecor: Decoration = {
    ...decorData,
    id: `d-${Date.now()}`,
  };
  saveDecorations([newDecor, ...decorations]);
  return newDecor;
}

export function updateDecoration(decoration: Decoration): Decoration {
  const decorations = getDecorations();
  const updated = decorations.map((d) => (d.id === decoration.id ? decoration : d));
  saveDecorations(updated);
  return decoration;
}

export function deleteDecoration(id: string): void {
  const decorations = getDecorations();
  const updated = decorations.filter((d) => d.id !== id);
  saveDecorations(updated);
}

// ------------------- BOOKINGS -------------------

export function getBookings(): Booking[] {
  if (!isClient()) return initialBookings;
  try {
    const raw = localStorage.getItem(BOOKINGS_KEY);
    if (!raw) {
      localStorage.setItem(BOOKINGS_KEY, JSON.stringify(initialBookings));
      return initialBookings;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error("Error reading bookings from localStorage", e);
    return initialBookings;
  }
}

export function saveBookings(bookings: Booking[]): void {
  if (!isClient()) return;
  try {
    localStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings));
    notifyStorageChange();
  } catch (e) {
    console.error("Error saving bookings to localStorage", e);
  }
}

export function addBooking(bookingData: Omit<Booking, "id" | "createdAt" | "status">): Booking {
  const bookings = getBookings();
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const newBooking: Booking = {
    ...bookingData,
    id: `BK-${randomSuffix}`,
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  saveBookings([newBooking, ...bookings]);
  return newBooking;
}

export function updateBookingStatus(id: string, status: BookingStatus): void {
  const bookings = getBookings();
  const updated = bookings.map((b) => (b.id === id ? { ...b, status } : b));
  saveBookings(updated);
}

export function deleteBooking(id: string): void {
  const bookings = getBookings();
  const updated = bookings.filter((b) => b.id !== id);
  saveBookings(updated);
}

export function resetToMockData(): void {
  if (!isClient()) return;
  localStorage.setItem(VENUES_KEY, JSON.stringify(initialVenues));
  localStorage.setItem(DECORATIONS_KEY, JSON.stringify(initialDecorations));
  localStorage.setItem(BOOKINGS_KEY, JSON.stringify(initialBookings));
  notifyStorageChange();
}
