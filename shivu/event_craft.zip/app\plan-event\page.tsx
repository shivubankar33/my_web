"use client";

import React, { useState, useEffect, useMemo, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useAuth } from "@/lib/authContext";
import { useToast } from "@/components/Toast";
import {
  getVenues,
  getDecorations,
  addBooking,
  STORAGE_CHANGE_EVENT,
} from "@/lib/storage";
import { addOnServicesList } from "@/data/mockData";
import { Venue, Decoration, AddOnService, Booking } from "@/types";
import { formatCurrency, formatDate } from "@/lib/utils";
import {
  Calendar,
  Clock,
  Users,
  Building2,
  Palette,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Search,
  Filter,
  AlertTriangle,
  Receipt,
  Utensils,
  Music,
  Camera,
  Layers,
  MapPin,
  Star,
  Check,
  Send,
  PartyPopper,
  ShieldCheck,
} from "lucide-react";
import Link from "next/link";

function EventPlannerWizard() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user } = useAuth();
  const { showToast } = useToast();

  // Dynamic Datasets from localStorage
  const [venues, setVenues] = useState<Venue[]>([]);
  const [decorations, setDecorations] = useState<Decoration[]>([]);

  // Wizard Navigation
  const [currentStep, setCurrentStep] = useState<number>(1);
  const totalSteps = 5;

  // Step 1: Event Details
  const [eventDate, setEventDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14); // 2 weeks out default
    return d.toISOString().split("T")[0];
  });
  const [eventTime, setEventTime] = useState<string>("17:00");
  const [durationHours, setDurationHours] = useState<number>(5);
  const [guestCount, setGuestCount] = useState<number>(120);

  // Step 2: Venue Selection
  const [selectedVenueId, setSelectedVenueId] = useState<string>("");
  const [venueSearch, setVenueSearch] = useState<string>("");
  const [maxVenuePrice, setMaxVenuePrice] = useState<number>(600);
  const [onlyFittingCapacity, setOnlyFittingCapacity] = useState<boolean>(false);

  // Step 3: Decoration & Theme
  const [selectedDecorationId, setSelectedDecorationId] = useState<string>("");
  const [decorCategory, setDecorCategory] = useState<string>("All");

  // Step 4: Add-On Services
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>(["addon-catering"]);

  // Step 5: Contact & Submission
  const [customerName, setCustomerName] = useState<string>("");
  const [customerEmail, setCustomerEmail] = useState<string>("");
  const [customerPhone, setCustomerPhone] = useState<string>("");
  const [notes, setNotes] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [completedBooking, setCompletedBooking] = useState<Booking | null>(null);

  // Load and subscribe to real-time storage updates
  useEffect(() => {
    const loadData = () => {
      const v = getVenues();
      const d = getDecorations();
      setVenues(v);
      setDecorations(d);

      // Pre-select first or URL parameter
      const venueParam = searchParams.get("venueId");
      if (venueParam && v.some((item) => item.id === venueParam)) {
        setSelectedVenueId(venueParam);
      } else if (v.length > 0 && !selectedVenueId) {
        setSelectedVenueId(v[0].id);
      }

      if (d.length > 0 && !selectedDecorationId) {
        setSelectedDecorationId(d[0].id);
      }
    };

    loadData();

    window.addEventListener(STORAGE_CHANGE_EVENT, loadData);
    return () => {
      window.removeEventListener(STORAGE_CHANGE_EVENT, loadData);
    };
  }, [searchParams]);

  // Sync user info into contact form if logged in
  useEffect(() => {
    if (user) {
      if (!customerName) setCustomerName(user.name);
      if (!customerEmail) setCustomerEmail(user.email);
      if (!customerPhone && user.phone) setCustomerPhone(user.phone);
    }
  }, [user]);

  // Selected Entities
  const selectedVenue = useMemo(
    () => venues.find((v) => v.id === selectedVenueId) || venues[0] || null,
    [venues, selectedVenueId]
  );

  const selectedDecoration = useMemo(
    () => decorations.find((d) => d.id === selectedDecorationId) || null,
    [decorations, selectedDecorationId]
  );

  // Cost Calculations
  const calculations = useMemo(() => {
    const venueCost = selectedVenue ? selectedVenue.pricePerHour * durationHours : 0;
    const decorationCost = selectedDecoration ? selectedDecoration.baselinePrice : 0;

    let addOnsCost = 0;
    selectedAddOns.forEach((addonId) => {
      const service = addOnServicesList.find((s) => s.id === addonId);
      if (service) {
        if (service.unit === "per_guest") {
          addOnsCost += service.price * guestCount;
        } else {
          addOnsCost += service.price;
        }
      }
    });

    const subtotal = venueCost + decorationCost + addOnsCost;
    const serviceFee = Math.round(subtotal * 0.05); // 5% coordinator fee
    const total = subtotal + serviceFee;

    return {
      venueCost,
      decorationCost,
      addOnsCost,
      serviceFee,
      total,
    };
  }, [selectedVenue, selectedDecoration, durationHours, selectedAddOns, guestCount]);

  // Filtered Venues
  const filteredVenues = useMemo(() => {
    return venues.filter((v) => {
      const matchesSearch =
        v.title.toLowerCase().includes(venueSearch.toLowerCase()) ||
        v.location.toLowerCase().includes(venueSearch.toLowerCase()) ||
        v.tags.some((t) => t.toLowerCase().includes(venueSearch.toLowerCase()));
      const matchesPrice = v.pricePerHour <= maxVenuePrice;
      const matchesCap = onlyFittingCapacity ? v.capacity >= guestCount : true;
      return matchesSearch && matchesPrice && matchesCap;
    });
  }, [venues, venueSearch, maxVenuePrice, onlyFittingCapacity, guestCount]);

  // Filtered Decor Categories
  const categories = useMemo(() => {
    const set = new Set(decorations.map((d) => d.category));
    return ["All", ...Array.from(set)];
  }, [decorations]);

  const filteredDecor = useMemo(() => {
    if (decorCategory === "All") return decorations;
    return decorations.filter((d) => d.category.toLowerCase() === decorCategory.toLowerCase());
  }, [decorations, decorCategory]);

  const toggleAddOn = (id: string) => {
    setSelectedAddOns((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleNextStep = () => {
    if (currentStep === 2 && !selectedVenueId) {
      showToast("Please choose a venue to continue.", "error");
      return;
    }
    if (currentStep < totalSteps) {
      setCurrentStep((prev) => prev + 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handleSubmitBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVenue) {
      showToast("Please select a venue before submitting.", "error");
      return;
    }
    if (!customerName.trim() || !customerEmail.trim()) {
      showToast("Please provide your name and contact email.", "error");
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const newBooking = addBooking({
        userId: user?.id || "guest-session",
        customerName,
        customerEmail,
        customerPhone: customerPhone || "N/A",
        venueId: selectedVenue.id,
        decorationId: selectedDecoration?.id || "none",
        guestCount,
        date: eventDate,
        time: eventTime,
        durationHours,
        addOns: selectedAddOns,
        totalBudget: calculations.total,
        notes,
      });

      setCompletedBooking(newBooking);
      setIsSubmitting(false);
      showToast("Booking request submitted successfully!", "success");
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, 600);
  };

  const renderAddonIcon = (iconName: string) => {
    switch (iconName) {
      case "Utensils":
        return <Utensils className="w-5 h-5 text-emerald-500" />;
      case "Music":
        return <Music className="w-5 h-5 text-indigo-500" />;
      case "Camera":
        return <Camera className="w-5 h-5 text-pink-500" />;
      case "Sparkles":
        return <Sparkles className="w-5 h-5 text-amber-500" />;
      default:
        return <Sparkles className="w-5 h-5 text-brand-500" />;
    }
  };

  // If Booking is confirmed, render celebratory receipt screen
  if (completedBooking) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center animate-fade-in">
        <div className="p-8 sm:p-12 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl relative overflow-hidden">
          <div className="w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto mb-6 shadow-inner">
            <PartyPopper className="w-10 h-10 animate-bounce" />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 text-xs font-bold mb-3">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Booking Request Confirmed</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
            You&apos;re All Set, {completedBooking.customerName}!
          </h2>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 max-w-lg mx-auto">
            Your event request has been dispatched to the venue host for instant approval.
          </p>

          <div className="mt-8 p-6 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-left max-w-xl mx-auto space-y-3">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 text-xs">
              <span className="text-slate-500">Booking Reference</span>
              <span className="font-mono font-bold text-brand-600 dark:text-brand-400">
                {completedBooking.id}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Venue</span>
              <span className="font-semibold text-slate-900 dark:text-white">
                {selectedVenue?.title}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Date & Duration</span>
              <span className="font-semibold text-slate-900 dark:text-white">
                {formatDate(completedBooking.date)} at {completedBooking.time} ({completedBooking.durationHours} hrs)
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Estimated Headcount</span>
              <span className="font-semibold text-slate-900 dark:text-white">
                {completedBooking.guestCount} Guests
              </span>
            </div>
            <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-slate-800">
              <span className="text-sm font-bold text-slate-900 dark:text-white">Total Budget Quote</span>
              <span className="text-lg font-extrabold text-emerald-600 dark:text-emerald-400">
                {formatCurrency(completedBooking.totalBudget)}
              </span>
            </div>
          </div>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => {
                setCompletedBooking(null);
                setCurrentStep(1);
              }}
              className="w-full sm:w-auto px-6 py-3 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            >
              Plan Another Event
            </button>
            <Link
              href="/admin"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-brand-600 to-purple-600 hover:from-brand-500 shadow-md shadow-brand-500/25 transition-all"
            >
              <ShieldCheck className="w-4 h-4 text-amber-300" />
              <span>Review In Host / Admin Portal</span>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
      {/* Wizard Step Tracker Header */}
      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-400 text-xs font-bold mb-2">
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          <span>EventCraft Stage & Experience Architect</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          EventCraft Interactive Planner Wizard
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Customize your venue, floral styling, sound, and catering step-by-step with real-time budget forecasting.
        </p>

        {/* Step Progress Bar */}
        <div className="mt-6 grid grid-cols-5 gap-2 sm:gap-4">
          {[
            { num: 1, label: "Details" },
            { num: 2, label: "Venue" },
            { num: 3, label: "Decor" },
            { num: 4, label: "Add-Ons" },
            { num: 5, label: "Summary" },
          ].map((s) => {
            const isCompleted = currentStep > s.num;
            const isCurrent = currentStep === s.num;
            return (
              <button
                key={s.num}
                type="button"
                onClick={() => isCompleted && setCurrentStep(s.num)}
                disabled={!isCompleted && !isCurrent}
                className={`flex flex-col sm:flex-row items-center sm:gap-2.5 p-2 sm:p-3 rounded-xl border text-left transition-all ${
                  isCurrent
                    ? "border-brand-500 bg-brand-50 dark:bg-brand-950/40 text-brand-700 dark:text-brand-300 ring-2 ring-brand-500/20"
                    : isCompleted
                    ? "border-emerald-500/40 bg-emerald-50/30 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400 cursor-pointer"
                    : "border-slate-200 dark:border-slate-800 text-slate-400 dark:text-slate-600 cursor-not-allowed opacity-60"
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                    isCompleted
                      ? "bg-emerald-500 text-white"
                      : isCurrent
                      ? "bg-brand-600 text-white"
                      : "bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                  }`}
                >
                  {isCompleted ? <Check className="w-3.5 h-3.5" /> : s.num}
                </div>
                <span className="text-[11px] sm:text-xs font-bold truncate mt-1 sm:mt-0">
                  {s.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main 2-Column Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Form Area (Steps 1-5) */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm min-h-[500px] flex flex-col justify-between">
          <div>
            {/* STEP 1: EVENT DETAILS */}
            {currentStep === 1 && (
              <div className="space-y-6 animate-fade-in">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-brand-500" />
                    <span>Step 1: Event Schedule & Headcount</span>
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Select your targeted event date, duration, and projected guest size.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Date */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      Event Date
                    </label>
                    <div className="relative">
                      <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="date"
                        value={eventDate}
                        min={new Date().toISOString().split("T")[0]}
                        onChange={(e) => setEventDate(e.target.value)}
                        className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                      />
                    </div>
                  </div>

                  {/* Start Time */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      Start Time
                    </label>
                    <div className="relative">
                      <Clock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="time"
                        value={eventTime}
                        onChange={(e) => setEventTime(e.target.value)}
                        className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Duration */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Duration (Hours)
                    </label>
                    <span className="text-xs font-bold text-brand-600 dark:text-brand-400">
                      {durationHours} Hours Reserved
                    </span>
                  </div>
                  <input
                    type="range"
                    min={2}
                    max={12}
                    step={1}
                    value={durationHours}
                    onChange={(e) => setDurationHours(Number(e.target.value))}
                    className="w-full accent-brand-600 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                    <span>2 hrs (Minimum)</span>
                    <span>6 hrs (Average)</span>
                    <span>12 hrs (Full Day)</span>
                  </div>
                </div>

                {/* Headcount Slider */}
                <div className="pt-2">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-brand-500" />
                      <span>Guest Headcount / Capacity</span>
                    </label>
                    <span className="text-sm font-extrabold text-brand-600 dark:text-brand-400 px-3 py-1 rounded-lg bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800">
                      {guestCount} Guests
                    </span>
                  </div>
                  <input
                    type="range"
                    min={10}
                    max={600}
                    step={10}
                    value={guestCount}
                    onChange={(e) => setGuestCount(Number(e.target.value))}
                    className="w-full accent-brand-600 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                    <span>10 (Intimate)</span>
                    <span>200 (Medium Gala)</span>
                    <span>600+ (Grand Banquet)</span>
                  </div>

                  {/* Preset quick buttons */}
                  <div className="flex flex-wrap gap-2 mt-4">
                    {[30, 80, 150, 250, 400].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setGuestCount(preset)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                          guestCount === preset
                            ? "bg-brand-600 text-white border-brand-600 shadow-sm"
                            : "bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100"
                        }`}
                      >
                        {preset} Guests
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* STEP 2: VENUE SELECTION */}
            {currentStep === 2 && (
              <div className="space-y-6 animate-fade-in">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-brand-500" />
                    <span>Step 2: Choose Your Destination Venue</span>
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Browse handpicked venues with verified acoustic, seating, and culinary accommodations.
                  </p>
                </div>

                {/* Filter and Search Bar */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3">
                  <div className="flex flex-col sm:flex-row gap-3">
                    <div className="relative flex-1">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        placeholder="Search venues by name, city, or style tags..."
                        value={venueSearch}
                        onChange={(e) => setVenueSearch(e.target.value)}
                        className="w-full pl-10 pr-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                      />
                    </div>
                    <label className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300 cursor-pointer sm:shrink-0">
                      <input
                        type="checkbox"
                        checked={onlyFittingCapacity}
                        onChange={(e) => setOnlyFittingCapacity(e.target.checked)}
                        className="rounded accent-brand-600"
                      />
                      <span>Fit current guests ({guestCount})</span>
                    </label>
                  </div>
                </div>

                {/* Venues Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[520px] overflow-y-auto pr-1">
                  {filteredVenues.length === 0 ? (
                    <div className="col-span-2 py-12 text-center text-slate-500 dark:text-slate-400">
                      <p className="text-sm font-semibold">No venues match your current filters.</p>
                      <button
                        onClick={() => {
                          setVenueSearch("");
                          setOnlyFittingCapacity(false);
                        }}
                        className="mt-2 text-xs text-brand-600 dark:text-brand-400 font-bold hover:underline"
                      >
                        Reset filters
                      </button>
                    </div>
                  ) : (
                    filteredVenues.map((v) => {
                      const isSelected = selectedVenueId === v.id;
                      const isTooSmall = v.capacity < guestCount;
                      return (
                        <div
                          key={v.id}
                          onClick={() => setSelectedVenueId(v.id)}
                          className={`rounded-2xl border overflow-hidden cursor-pointer transition-all flex flex-col justify-between ${
                            isSelected
                              ? "border-brand-500 bg-brand-50/30 dark:bg-brand-950/40 ring-2 ring-brand-500 shadow-md"
                              : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 hover:border-brand-300"
                          }`}
                        >
                          <div className="relative h-44 w-full bg-slate-800">
                            <img
                              src={v.image}
                              alt={v.title}
                              className="w-full h-full object-cover"
                              loading="lazy"
                            />
                            <div className="absolute top-2.5 right-2.5 px-2.5 py-0.5 rounded-full bg-slate-950/80 backdrop-blur-md text-white text-[11px] font-bold flex items-center gap-1">
                              <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                              <span>{v.rating || 4.9}</span>
                            </div>
                            <div className="absolute bottom-2.5 left-2.5 px-2.5 py-1 rounded-md bg-white/90 dark:bg-slate-950/90 backdrop-blur-md text-[11px] font-bold text-slate-800 dark:text-slate-200">
                              Max {v.capacity} Guests
                            </div>
                          </div>

                          <div className="p-4 flex-1 flex flex-col justify-between">
                            <div>
                              <div className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 mb-1">
                                <MapPin className="w-3 h-3 text-brand-500 shrink-0" />
                                <span className="truncate">{v.location}</span>
                              </div>
                              <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                                {v.title}
                              </h3>
                              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                                {v.description}
                              </p>

                              {isTooSmall && (
                                <div className="mt-2.5 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-400 text-[11px]">
                                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                                  <span>Capacity ({v.capacity}) is below {guestCount} guests</span>
                                </div>
                              )}
                            </div>

                            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between">
                              <div>
                                <span className="text-[10px] text-slate-400">Rate</span>
                                <p className="text-xs font-bold text-slate-900 dark:text-white">
                                  {formatCurrency(v.pricePerHour)}/hr
                                </p>
                              </div>
                              <div
                                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors ${
                                  isSelected
                                    ? "bg-brand-600 text-white"
                                    : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                                }`}
                              >
                                {isSelected ? (
                                  <>
                                    <Check className="w-3.5 h-3.5" />
                                    <span>Selected</span>
                                  </>
                                ) : (
                                  <span>Choose</span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}

            {/* STEP 3: DECORATION & THEME */}
            {currentStep === 3 && (
              <div className="space-y-6 animate-fade-in">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                    <Palette className="w-5 h-5 text-brand-500" />
                    <span>Step 3: Bespoke Decor & Atmospheric Themes</span>
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Select a curated styling collection with custom centerpiece florals, lighting arrays, and backdrops.
                  </p>
                </div>

                {/* Category Pills */}
                <div className="flex flex-wrap gap-2">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setDecorCategory(cat)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                        decorCategory === cat
                          ? "bg-brand-600 text-white shadow-sm"
                          : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {/* Decoration Packages Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[520px] overflow-y-auto pr-1">
                  {filteredDecor.map((d) => {
                    const isSelected = selectedDecorationId === d.id;
                    return (
                      <div
                        key={d.id}
                        onClick={() => setSelectedDecorationId(d.id)}
                        className={`rounded-2xl border overflow-hidden cursor-pointer transition-all flex flex-col justify-between ${
                          isSelected
                            ? "border-brand-500 bg-brand-50/30 dark:bg-brand-950/40 ring-2 ring-brand-500 shadow-md"
                            : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 hover:border-brand-300"
                        }`}
                      >
                        <div className="relative h-40 w-full bg-slate-800">
                          <img
                            src={d.image}
                            alt={d.title}
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                          <div className="absolute top-2.5 left-2.5 px-2.5 py-0.5 rounded-full bg-slate-950/80 backdrop-blur-md text-brand-300 text-[10px] font-bold uppercase tracking-wider">
                            {d.category}
                          </div>
                          <div className="absolute bottom-2.5 right-2.5 px-2.5 py-1 rounded-md bg-white/90 dark:bg-slate-950/90 backdrop-blur-md text-xs font-bold text-slate-900 dark:text-white">
                            {formatCurrency(d.baselinePrice)}
                          </div>
                        </div>

                        <div className="p-4 flex-1 flex flex-col justify-between">
                          <div>
                            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                              {d.title}
                            </h3>
                            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                              {d.description}
                            </p>

                            {d.includedItems && (
                              <div className="mt-3 flex flex-wrap gap-1.5">
                                {d.includedItems.slice(0, 3).map((item, idx) => (
                                  <span
                                    key={idx}
                                    className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium"
                                  >
                                    ✓ {item}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>

                          <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                              Package Investment
                            </span>
                            <div
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors ${
                                isSelected
                                  ? "bg-brand-600 text-white"
                                  : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                              }`}
                            >
                              {isSelected ? (
                                <>
                                  <Check className="w-3.5 h-3.5" />
                                  <span>Selected</span>
                                </>
                              ) : (
                                <span>Choose Theme</span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 4: ADD-ON SERVICES */}
            {currentStep === 4 && (
              <div className="space-y-6 animate-fade-in">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-brand-500" />
                    <span>Step 4: Premium Event Add-On Services</span>
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Select world-class culinary packages, sound production, and cinematography.
                  </p>
                </div>

                <div className="space-y-3">
                  {addOnServicesList.map((addon) => {
                    const isChecked = selectedAddOns.includes(addon.id);
                    const calculatedCost =
                      addon.unit === "per_guest" ? addon.price * guestCount : addon.price;

                    return (
                      <div
                        key={addon.id}
                        onClick={() => toggleAddOn(addon.id)}
                        className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start gap-4 ${
                          isChecked
                            ? "border-brand-500 bg-brand-50/40 dark:bg-brand-950/40 ring-2 ring-brand-500/20"
                            : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40"
                        }`}
                      >
                        <div className="mt-0.5">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}} // Controlled by wrapper div
                            className="w-5 h-5 rounded border-slate-300 text-brand-600 focus:ring-brand-500 accent-brand-600 cursor-pointer"
                          />
                        </div>

                        <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                          {renderAddonIcon(addon.iconName)}
                        </div>

                        <div className="flex-1">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                              {addon.name}
                            </h3>
                            <div className="text-right">
                              <span className="text-sm font-extrabold text-brand-600 dark:text-brand-400">
                                {formatCurrency(calculatedCost)}
                              </span>
                              {addon.unit === "per_guest" && (
                                <span className="text-[11px] text-slate-400 ml-1">
                                  ({formatCurrency(addon.price)} / guest)
                                </span>
                              )}
                            </div>
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                            {addon.description}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 5: SUMMARY & CONFIRMATION */}
            {currentStep === 5 && (
              <form onSubmit={handleSubmitBooking} className="space-y-6 animate-fade-in">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                    <Receipt className="w-5 h-5 text-brand-500" />
                    <span>Step 5: Review & Submit Booking Request</span>
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Verify your event details and enter your planner contact information to dispatch.
                  </p>
                </div>

                {/* Event Summary Recap Card */}
                <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Configuration Snapshot
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div>
                      <span className="text-slate-400">Date & Time</span>
                      <p className="font-semibold text-slate-900 dark:text-white">
                        {formatDate(eventDate)} @ {eventTime}
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400">Duration</span>
                      <p className="font-semibold text-slate-900 dark:text-white">
                        {durationHours} Hours
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400">Headcount</span>
                      <p className="font-semibold text-slate-900 dark:text-white">
                        {guestCount} Guests
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400">Selected Venue</span>
                      <p className="font-semibold text-slate-900 dark:text-white truncate">
                        {selectedVenue?.title}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Contact Form Inputs */}
                <div className="space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Lead Planner / Customer Details
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="e.g. Jessica Sterling"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        required
                        value={customerEmail}
                        onChange={(e) => setCustomerEmail(e.target.value)}
                        placeholder="jessica@eventcraft.io"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="+1 (555) 301-8492"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Special Requests / Notes to Host
                    </label>
                    <textarea
                      rows={3}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Mention any dietary requirements, sound check requests, or custom stage configurations..."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 px-6 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-xl shadow-emerald-600/25 hover:shadow-emerald-600/40 hover:scale-[1.01] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSubmitting ? "Dispatching Reservation..." : "Confirm & Send Booking Request"}</span>
                </button>
              </form>
            )}
          </div>

          {/* Wizard Action Footer Bar */}
          <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <button
              type="button"
              onClick={handlePrevStep}
              disabled={currentStep === 1}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold border transition-all ${
                currentStep === 1
                  ? "opacity-40 cursor-not-allowed border-slate-200 dark:border-slate-800 text-slate-400"
                  : "border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              }`}
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            {currentStep < totalSteps && (
              <button
                type="button"
                onClick={handleNextStep}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-brand-600 hover:bg-brand-500 shadow-md shadow-brand-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Right Sticky Summary Sidebar: Real-Time Dynamic Cost Calculator */}
        <div className="lg:col-span-4 sticky top-24 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-lg">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-brand-500" />
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                  Cost Calculator
                </h3>
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                Live Pricing
              </span>
            </div>

            {/* Selected Components Breakdown */}
            <div className="mt-4 space-y-3.5 text-xs">
              {/* Venue */}
              <div>
                <div className="flex justify-between font-medium">
                  <span className="text-slate-600 dark:text-slate-400 truncate max-w-[170px]">
                    {selectedVenue?.title || "No Venue Selected"}
                  </span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {formatCurrency(calculations.venueCost)}
                  </span>
                </div>
                {selectedVenue && (
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    {formatCurrency(selectedVenue.pricePerHour)}/hr × {durationHours} hrs
                  </p>
                )}
              </div>

              {/* Decor Theme */}
              <div>
                <div className="flex justify-between font-medium">
                  <span className="text-slate-600 dark:text-slate-400 truncate max-w-[170px]">
                    {selectedDecoration?.title || "No Theme Selected"}
                  </span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {formatCurrency(calculations.decorationCost)}
                  </span>
                </div>
                {selectedDecoration && (
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    Baseline styling & floral install
                  </p>
                )}
              </div>

              {/* Add-ons */}
              {selectedAddOns.length > 0 && (
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80">
                  <div className="flex justify-between font-medium mb-1.5">
                    <span className="text-slate-600 dark:text-slate-400">
                      Add-on Services ({selectedAddOns.length})
                    </span>
                    <span className="font-bold text-slate-900 dark:text-white">
                      {formatCurrency(calculations.addOnsCost)}
                    </span>
                  </div>
                  <ul className="space-y-1 pl-2">
                    {selectedAddOns.map((id) => {
                      const item = addOnServicesList.find((s) => s.id === id);
                      if (!item) return null;
                      return (
                        <li key={id} className="text-[11px] text-slate-400 flex justify-between">
                          <span className="truncate max-w-[150px]">✦ {item.name}</span>
                          <span>
                            {item.unit === "per_guest"
                              ? formatCurrency(item.price * guestCount)
                              : formatCurrency(item.price)}
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              )}

              {/* Service Coordinator Fee */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex justify-between font-medium text-slate-500">
                <span>Coordination & Service (5%)</span>
                <span>{formatCurrency(calculations.serviceFee)}</span>
              </div>

              {/* Grand Total */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-baseline justify-between">
                <div>
                  <span className="text-xs uppercase font-extrabold tracking-wider text-slate-500">
                    Estimated Total
                  </span>
                  <p className="text-[10px] text-slate-400">Taxes & setups included</p>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-black text-brand-600 dark:text-brand-400">
                    {formatCurrency(calculations.total)}
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Summary Pill Footer */}
            <div className="mt-5 p-3 rounded-xl bg-brand-50/50 dark:bg-brand-950/30 border border-brand-200/50 dark:border-brand-900/50 text-[11px] text-slate-600 dark:text-slate-400 space-y-1">
              <p className="flex items-center gap-1.5 font-medium text-slate-800 dark:text-slate-200">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                <span>Zero deposit required to submit request</span>
              </p>
              <p className="text-slate-400 pl-5">
                Host guarantees a response within 24 business hours.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function PlanEventPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center">
          <p className="text-sm font-semibold text-brand-500">Loading Event Planner...</p>
        </div>
      }
    >
      <EventPlannerWizard />
    </Suspense>
  );
}
