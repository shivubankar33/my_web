"use client";

import React, { useState, useEffect, useMemo } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/authContext";
import { useToast } from "@/components/Toast";
import {
  getVenues,
  addVenue,
  deleteVenue,
  getDecorations,
  addDecoration,
  deleteDecoration,
  getBookings,
  updateBookingStatus,
  deleteBooking,
  resetToMockData,
  STORAGE_CHANGE_EVENT,
} from "@/lib/storage";
import { Venue, Decoration, Booking, BookingStatus } from "@/types";
import { formatCurrency, formatDate } from "@/lib/utils";
import {
  ShieldAlert,
  ShieldCheck,
  Building2,
  Palette,
  CalendarCheck,
  Plus,
  Trash2,
  CheckCircle2,
  XCircle,
  Clock,
  ExternalLink,
  DollarSign,
  Users,
  Search,
  Sparkles,
  RefreshCw,
  MapPin,
  ChevronRight,
  UserCheck,
  Upload,
  Image as ImageIcon,
  X,
  Link2,
  FileCheck,
} from "lucide-react";

export default function AdminPage() {
  const { user, role, loginQuick } = useAuth();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<"venues" | "decorations" | "bookings">("venues");

  // Local State synced with storage
  const [venues, setVenues] = useState<Venue[]>([]);
  const [decorations, setDecorations] = useState<Decoration[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);

  // Search/Filters in Admin
  const [bookingFilter, setBookingFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Modal / Form state for Venues
  const [showAddVenue, setShowAddVenue] = useState<boolean>(false);
  const [venueTitle, setVenueTitle] = useState("");
  const [venueImageUrl, setVenueImageUrl] = useState("");
  const [venueImgMode, setVenueImgMode] = useState<"upload" | "url">("upload");
  const [venueFilePreview, setVenueFilePreview] = useState<string>("");
  const [venueFileName, setVenueFileName] = useState<string>("");
  const [venueCapacity, setVenueCapacity] = useState<number>(200);
  const [venuePrice, setVenuePrice] = useState<number>(300);
  const [venueLocation, setVenueLocation] = useState("");
  const [venueDescription, setVenueDescription] = useState("");
  const [venueTags, setVenueTags] = useState("");

  // Modal / Form state for Decorations
  const [showAddDecor, setShowAddDecor] = useState<boolean>(false);
  const [decorTitle, setDecorTitle] = useState("");
  const [decorImageUrl, setDecorImageUrl] = useState("");
  const [decorImgMode, setDecorImgMode] = useState<"upload" | "url">("upload");
  const [decorFilePreview, setDecorFilePreview] = useState<string>("");
  const [decorFileName, setDecorFileName] = useState<string>("");
  const [decorCategory, setDecorCategory] = useState("Luxury");
  const [decorPrice, setDecorPrice] = useState<number>(1200);
  const [decorDescription, setDecorDescription] = useState("");
  const [decorItems, setDecorItems] = useState("");

  // Direct Image File Upload Handlers
  const handleVenueFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith("image/")) {
        showToast("Please select a valid JPG, PNG, or WebP image file.", "error");
        return;
      }
      setVenueFileName(file.name);
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          setVenueFilePreview(reader.result);
          setVenueImageUrl(reader.result);
          showToast(`Venue photo "${file.name}" loaded ready to publish.`, "success");
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDecorFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith("image/")) {
        showToast("Please select a valid JPG, PNG, or WebP image file.", "error");
        return;
      }
      setDecorFileName(file.name);
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          setDecorFilePreview(reader.result);
          setDecorImageUrl(reader.result);
          showToast(`Theme photo "${file.name}" loaded ready to publish.`, "success");
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const refreshData = () => {
    setVenues(getVenues());
    setDecorations(getDecorations());
    setBookings(getBookings());
  };

  useEffect(() => {
    refreshData();
    window.addEventListener(STORAGE_CHANGE_EVENT, refreshData);
    return () => {
      window.removeEventListener(STORAGE_CHANGE_EVENT, refreshData);
    };
  }, []);

  // Quick Preset Sample Images for ease of testing
  const sampleVenueImages = [
    { label: "Waterfront Villa", url: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1200&q=80" },
    { label: "Chateau Courtyard", url: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80" },
    { label: "Modern Art Gallery", url: "https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?auto=format&fit=crop&w=1200&q=80" },
  ];

  const sampleDecorImages = [
    { label: "Gilded Velvet", url: "https://images.unsplash.com/photo-1532712938310-34cb3982ef74?auto=format&fit=crop&w=800&q=80" },
    { label: "Pastel Meadow", url: "https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=800&q=80" },
  ];

  // METRICS
  const metrics = useMemo(() => {
    const totalPipeline = bookings.reduce((sum, b) => sum + b.totalBudget, 0);
    const pendingCount = bookings.filter((b) => b.status === "pending").length;
    const approvedCount = bookings.filter((b) => b.status === "approved").length;

    return {
      totalPipeline,
      pendingCount,
      approvedCount,
      totalVenues: venues.length,
      totalDecor: decorations.length,
    };
  }, [bookings, venues, decorations]);

  // Handlers for Venues
  const handleCreateVenue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!venueTitle.trim()) {
      showToast("Venue title is required.", "error");
      return;
    }

    const tagsArray = venueTags
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);

    addVenue({
      title: venueTitle,
      image:
        venueImageUrl.trim() ||
        "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=80",
      capacity: Number(venueCapacity) || 100,
      pricePerHour: Number(venuePrice) || 200,
      location: venueLocation || "Metropolitan City Center",
      description: venueDescription || "Modern premier event location.",
      tags: tagsArray.length > 0 ? tagsArray : ["Modern", "Indoor"],
      rating: 5.0,
      amenities: ["Lighting Rig", "Air Conditioned", "Prep Kitchen"],
    });

    showToast(`Venue "${venueTitle}" published live to Event Planner!`, "success");
    setVenueTitle("");
    setVenueImageUrl("");
    setVenueFilePreview("");
    setVenueFileName("");
    setVenueDescription("");
    setVenueLocation("");
    setVenueTags("");
    setShowAddVenue(false);
  };

  const handleDeleteVenue = (id: string, title: string) => {
    if (confirm(`Are you sure you want to remove the venue "${title}"?`)) {
      deleteVenue(id);
      showToast(`Venue "${title}" removed.`, "info");
    }
  };

  // Handlers for Decorations
  const handleCreateDecor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!decorTitle.trim()) {
      showToast("Theme title is required.", "error");
      return;
    }

    const itemsArray = decorItems
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean);

    addDecoration({
      title: decorTitle,
      image:
        decorImageUrl.trim() ||
        "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=800&q=80",
      category: decorCategory,
      baselinePrice: Number(decorPrice) || 1000,
      description: decorDescription || "Curated theme package.",
      includedItems: itemsArray.length > 0 ? itemsArray : ["Centerpieces", "Draping", "Mood Lights"],
    });

    showToast(`Theme "${decorTitle}" added live to Event Planner!`, "success");
    setDecorTitle("");
    setDecorImageUrl("");
    setDecorFilePreview("");
    setDecorFileName("");
    setDecorDescription("");
    setDecorItems("");
    setShowAddDecor(false);
  };

  const handleDeleteDecor = (id: string, title: string) => {
    if (confirm(`Remove decoration theme "${title}"?`)) {
      deleteDecoration(id);
      showToast(`Theme "${title}" removed.`, "info");
    }
  };

  // Handlers for Bookings
  const handleStatusChange = (id: string, newStatus: BookingStatus) => {
    updateBookingStatus(id, newStatus);
    showToast(`Booking ${id} set to ${newStatus.toUpperCase()}`, "success");
  };

  const handleDeleteBooking = (id: string) => {
    if (confirm(`Delete record for booking ${id}?`)) {
      deleteBooking(id);
      showToast(`Booking ${id} deleted.`, "info");
    }
  };

  // Filtered Bookings
  const filteredBookings = useMemo(() => {
    return bookings.filter((b) => {
      const matchesStatus = bookingFilter === "all" ? true : b.status === bookingFilter;
      const matchesQuery =
        b.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        b.customerEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
        b.id.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesStatus && matchesQuery;
    });
  }, [bookings, bookingFilter, searchQuery]);

  // ----------------- AUTHORIZATION GUARD -----------------
  if (role !== "host") {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-2xl text-center">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto mb-4 border border-amber-500/20">
            <ShieldAlert className="w-8 h-8" />
          </div>

          <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">
            Host Authorization Required
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            The Host & Admin Portal is restricted to verified venue proprietors and administrators.
            You are currently signed in as {user ? `"${user.name}" (${role})` : "a Guest"}.
          </p>

          <div className="mt-6 space-y-3">
            <button
              onClick={() => loginQuick("host")}
              className="w-full py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-slate-950 bg-amber-500 hover:bg-amber-400 shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              <UserCheck className="w-4 h-4 text-slate-950" />
              <span>1-Click Switch to Host (Marcus Vance)</span>
            </button>

            <Link
              href="/login?role=host"
              className="w-full inline-flex items-center justify-center py-2.5 px-4 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 transition-colors"
            >
              Sign In with Host Account
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-10 space-y-8 animate-fade-in">
      {/* Top Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-400 text-xs font-bold mb-2">
            <ShieldCheck className="w-4 h-4" />
            <span>EventCraft Authenticated Host Portal: {user?.name}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            EventCraft Host & Admin Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Manage your estate inventory, bespoke floral styling themes, and customer reservation pipeline.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Link
            href="/plan-event"
            target="_blank"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 border border-slate-200 dark:border-slate-700 transition-colors"
          >
            <span>Open Planner Wizard</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </Link>
          <button
            onClick={() => {
              if (confirm("Reset venues, decorations, and bookings to default sample data?")) {
                resetToMockData();
                showToast("Data restored to initial mock dataset.", "info");
              }
            }}
            title="Reset Mock Data"
            className="p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:hover:text-white bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Metrics Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
            <span>Pipeline Budget</span>
            <DollarSign className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-2xl font-extrabold text-slate-900 dark:text-white">
            {formatCurrency(metrics.totalPipeline)}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">{bookings.length} total inquiries</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
            <span>Pending Requests</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-2xl font-extrabold text-amber-600 dark:text-amber-400">
            {metrics.pendingCount}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Requires review & action</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
            <span>Active Venues</span>
            <Building2 className="w-4 h-4 text-brand-500" />
          </div>
          <p className="text-2xl font-extrabold text-slate-900 dark:text-white">
            {metrics.totalVenues}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Available in wizard</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
            <span>Decor Packages</span>
            <Palette className="w-4 h-4 text-purple-500" />
          </div>
          <p className="text-2xl font-extrabold text-slate-900 dark:text-white">
            {metrics.totalDecor}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Curated themes listed</p>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab("venues")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === "venues"
              ? "bg-brand-600 text-white shadow-md shadow-brand-500/25"
              : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900"
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Manage Venues ({venues.length})</span>
        </button>

        <button
          onClick={() => setActiveTab("decorations")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === "decorations"
              ? "bg-brand-600 text-white shadow-md shadow-brand-500/25"
              : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900"
          }`}
        >
          <Palette className="w-4 h-4" />
          <span>Manage Themes ({decorations.length})</span>
        </button>

        <button
          onClick={() => setActiveTab("bookings")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === "bookings"
              ? "bg-brand-600 text-white shadow-md shadow-brand-500/25"
              : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900"
          }`}
        >
          <CalendarCheck className="w-4 h-4" />
          <span>Booking Requests ({bookings.length})</span>
          {metrics.pendingCount > 0 && (
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse ml-0.5" />
          )}
        </button>
      </div>

      {/* ----------------- TAB 1: MANAGE VENUES ----------------- */}
      {activeTab === "venues" && (
        <div className="space-y-6 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Live Listed Venues
              </h2>
              <p className="text-xs text-slate-500">
                Any addition or removal here immediately synchronizes with the client Event Planner.
              </p>
            </div>
            <button
              onClick={() => setShowAddVenue(!showAddVenue)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-brand-600 to-purple-600 hover:from-brand-500 shadow-md shadow-brand-500/20"
            >
              <Plus className="w-4 h-4" />
              <span>{showAddVenue ? "Close Form" : "Add New Venue"}</span>
            </button>
          </div>

          {/* Add Venue Form Drawer */}
          {showAddVenue && (
            <form
              onSubmit={handleCreateVenue}
              className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900/90 border border-brand-500/30 shadow-xl space-y-4 animate-slide-up"
            >
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-brand-500" />
                <span>Create & Publish New Venue</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold mb-1">Venue Title *</label>
                  <input
                    type="text"
                    required
                    value={venueTitle}
                    onChange={(e) => setVenueTitle(e.target.value)}
                    placeholder="e.g. Celestial Glass Pavilion"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold mb-1">Max Capacity (Guests)</label>
                  <input
                    type="number"
                    min={10}
                    max={2000}
                    value={venueCapacity}
                    onChange={(e) => setVenueCapacity(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold mb-1">Price per Hour ($)</label>
                  <input
                    type="number"
                    min={50}
                    value={venuePrice}
                    onChange={(e) => setVenuePrice(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold mb-1">Location / Address</label>
                  <input
                    type="text"
                    value={venueLocation}
                    onChange={(e) => setVenueLocation(e.target.value)}
                    placeholder="e.g. Upper West Side, Manhattan"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold mb-1">Tags (Comma-separated)</label>
                  <input
                    type="text"
                    value={venueTags}
                    onChange={(e) => setVenueTags(e.target.value)}
                    placeholder="e.g. Rooftop, Panoramic, Modern"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Venue Image Upload or URL Selector */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-semibold">
                    Venue Cover Photo / Image *
                  </label>
                  {/* Mode Toggle Switch */}
                  <div className="flex items-center p-0.5 rounded-lg bg-slate-200 dark:bg-slate-800 text-[11px] font-semibold">
                    <button
                      type="button"
                      onClick={() => setVenueImgMode("upload")}
                      className={`px-2.5 py-1 rounded-md transition-all flex items-center gap-1 ${
                        venueImgMode === "upload"
                          ? "bg-white dark:bg-slate-900 text-brand-600 dark:text-brand-400 shadow-xs"
                          : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                      }`}
                    >
                      <Upload className="w-3 h-3" />
                      <span>Upload JPG / File</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setVenueImgMode("url")}
                      className={`px-2.5 py-1 rounded-md transition-all flex items-center gap-1 ${
                        venueImgMode === "url"
                          ? "bg-white dark:bg-slate-900 text-brand-600 dark:text-brand-400 shadow-xs"
                          : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                      }`}
                    >
                      <Link2 className="w-3 h-3" />
                      <span>Online URL / Presets</span>
                    </button>
                  </div>
                </div>

                {venueImgMode === "upload" ? (
                  <div>
                    {venueFilePreview ? (
                      /* File Preview Card */
                      <div className="relative rounded-2xl border border-brand-500/40 bg-slate-100 dark:bg-slate-900/60 p-3 flex items-center gap-4">
                        <img
                          src={venueFilePreview}
                          alt="Venue preview"
                          className="w-20 h-16 object-cover rounded-xl border border-slate-300 dark:border-slate-700 shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-100">
                            <FileCheck className="w-4 h-4 text-emerald-500" />
                            <span className="truncate">{venueFileName || "Uploaded Image File"}</span>
                          </div>
                          <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium mt-0.5">
                            Direct image loaded & ready to publish
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setVenueFilePreview("");
                            setVenueFileName("");
                            setVenueImageUrl("");
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors"
                          title="Remove uploaded image"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      /* Upload Dropzone */
                      <label className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-brand-500 dark:hover:border-brand-400 bg-white dark:bg-slate-950/60 rounded-2xl p-5 flex flex-col items-center justify-center cursor-pointer transition-colors group">
                        <input
                          type="file"
                          accept="image/png, image/jpeg, image/jpg, image/webp"
                          onChange={handleVenueFileChange}
                          className="hidden"
                        />
                        <div className="w-10 h-10 rounded-xl bg-brand-50 dark:bg-brand-950/60 text-brand-600 dark:text-brand-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                          <Upload className="w-5 h-5" />
                        </div>
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                          Click to upload or drag & drop direct image
                        </p>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Supports JPG, PNG, or WebP photo files
                        </p>
                      </label>
                    )}
                  </div>
                ) : (
                  <div>
                    <input
                      type="url"
                      value={venueImageUrl}
                      onChange={(e) => {
                        setVenueImageUrl(e.target.value);
                        setVenueFilePreview(e.target.value);
                      }}
                      placeholder="https://images.unsplash.com/..."
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                    />
                    {/* Presets */}
                    <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
                      <span>Quick Presets:</span>
                      {sampleVenueImages.map((s, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setVenueImageUrl(s.url);
                            setVenueFilePreview(s.url);
                            setVenueFileName(s.label);
                          }}
                          className="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-800 hover:text-brand-400 text-slate-700 dark:text-slate-300 font-medium"
                        >
                          {s.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Description</label>
                <textarea
                  rows={2}
                  value={venueDescription}
                  onChange={(e) => setVenueDescription(e.target.value)}
                  placeholder="Detail the architecture, natural light, acoustic treatments, or exclusive terrace spaces..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddVenue(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-brand-600 hover:bg-brand-500 shadow-md"
                >
                  Save & Publish Venue
                </button>
              </div>
            </form>
          )}

          {/* Venues Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {venues.map((v) => (
              <div
                key={v.id}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm flex flex-col justify-between"
              >
                <div className="relative h-44 w-full bg-slate-800">
                  <img src={v.image} alt={v.title} className="w-full h-full object-cover" />
                  <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full bg-slate-950/80 text-[10px] font-bold text-white">
                    Cap: {v.capacity}
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <p className="text-[11px] text-brand-600 dark:text-brand-400 font-semibold truncate flex items-center gap-1">
                      <MapPin className="w-3 h-3 shrink-0" />
                      <span>{v.location}</span>
                    </p>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                      {v.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">{v.description}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400">Pricing</span>
                      <p className="text-xs font-bold text-slate-900 dark:text-white">
                        {formatCurrency(v.pricePerHour)}/hr
                      </p>
                    </div>

                    <button
                      onClick={() => handleDeleteVenue(v.id, v.title)}
                      className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors"
                      title="Delete Venue"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ----------------- TAB 2: MANAGE DECORATIONS ----------------- */}
      {activeTab === "decorations" && (
        <div className="space-y-6 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Styling & Decoration Themes
              </h2>
              <p className="text-xs text-slate-500">
                Curate theme packages available to clients during Step 3 of the planner wizard.
              </p>
            </div>
            <button
              onClick={() => setShowAddDecor(!showAddDecor)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-brand-600 to-purple-600 hover:from-brand-500 shadow-md shadow-brand-500/20"
            >
              <Plus className="w-4 h-4" />
              <span>{showAddDecor ? "Close Form" : "Create Theme Package"}</span>
            </button>
          </div>

          {/* Add Decor Package Form */}
          {showAddDecor && (
            <form
              onSubmit={handleCreateDecor}
              className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900/90 border border-brand-500/30 shadow-xl space-y-4 animate-slide-up"
            >
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Palette className="w-4 h-4 text-brand-500" />
                <span>Create New Decoration Package</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold mb-1">Theme Title *</label>
                  <input
                    type="text"
                    required
                    value={decorTitle}
                    onChange={(e) => setDecorTitle(e.target.value)}
                    placeholder="e.g. Arctic Minimalist Frost"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold mb-1">Category</label>
                  <select
                    value={decorCategory}
                    onChange={(e) => setDecorCategory(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                  >
                    <option value="Luxury">Luxury</option>
                    <option value="Romantic">Romantic</option>
                    <option value="Modern">Modern</option>
                    <option value="Bohemian">Bohemian</option>
                    <option value="Thematic">Thematic</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold mb-1">Baseline Package Price ($)</label>
                  <input
                    type="number"
                    min={100}
                    value={decorPrice}
                    onChange={(e) => setDecorPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Theme Image Upload or URL Selector */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-semibold">
                    Theme Cover Photo / Image *
                  </label>
                  {/* Mode Toggle Switch */}
                  <div className="flex items-center p-0.5 rounded-lg bg-slate-200 dark:bg-slate-800 text-[11px] font-semibold">
                    <button
                      type="button"
                      onClick={() => setDecorImgMode("upload")}
                      className={`px-2.5 py-1 rounded-md transition-all flex items-center gap-1 ${
                        decorImgMode === "upload"
                          ? "bg-white dark:bg-slate-900 text-brand-600 dark:text-brand-400 shadow-xs"
                          : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                      }`}
                    >
                      <Upload className="w-3 h-3" />
                      <span>Upload JPG / File</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setDecorImgMode("url")}
                      className={`px-2.5 py-1 rounded-md transition-all flex items-center gap-1 ${
                        decorImgMode === "url"
                          ? "bg-white dark:bg-slate-900 text-brand-600 dark:text-brand-400 shadow-xs"
                          : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                      }`}
                    >
                      <Link2 className="w-3 h-3" />
                      <span>Online URL / Presets</span>
                    </button>
                  </div>
                </div>

                {decorImgMode === "upload" ? (
                  <div>
                    {decorFilePreview ? (
                      /* File Preview Card */
                      <div className="relative rounded-2xl border border-brand-500/40 bg-slate-100 dark:bg-slate-900/60 p-3 flex items-center gap-4">
                        <img
                          src={decorFilePreview}
                          alt="Theme preview"
                          className="w-20 h-16 object-cover rounded-xl border border-slate-300 dark:border-slate-700 shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-100">
                            <FileCheck className="w-4 h-4 text-emerald-500" />
                            <span className="truncate">{decorFileName || "Uploaded Theme Image"}</span>
                          </div>
                          <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium mt-0.5">
                            Direct theme image loaded & ready to publish
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setDecorFilePreview("");
                            setDecorFileName("");
                            setDecorImageUrl("");
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors"
                          title="Remove uploaded image"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      /* Upload Dropzone */
                      <label className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-brand-500 dark:hover:border-brand-400 bg-white dark:bg-slate-950/60 rounded-2xl p-5 flex flex-col items-center justify-center cursor-pointer transition-colors group">
                        <input
                          type="file"
                          accept="image/png, image/jpeg, image/jpg, image/webp"
                          onChange={handleDecorFileChange}
                          className="hidden"
                        />
                        <div className="w-10 h-10 rounded-xl bg-brand-50 dark:bg-brand-950/60 text-brand-600 dark:text-brand-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                          <Upload className="w-5 h-5" />
                        </div>
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                          Click to upload or drag & drop direct image
                        </p>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Supports JPG, PNG, or WebP photo files
                        </p>
                      </label>
                    )}
                  </div>
                ) : (
                  <div>
                    <input
                      type="url"
                      value={decorImageUrl}
                      onChange={(e) => {
                        setDecorImageUrl(e.target.value);
                        setDecorFilePreview(e.target.value);
                      }}
                      placeholder="https://images.unsplash.com/..."
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                    />
                    <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
                      <span>Quick Presets:</span>
                      {sampleDecorImages.map((s, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setDecorImageUrl(s.url);
                            setDecorFilePreview(s.url);
                            setDecorFileName(s.label);
                          }}
                          className="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-800 hover:text-brand-400 text-slate-700 dark:text-slate-300 font-medium"
                        >
                          {s.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">
                  Included Inclusions (Comma-separated)
                </label>
                <input
                  type="text"
                  value={decorItems}
                  onChange={(e) => setDecorItems(e.target.value)}
                  placeholder="e.g. Floral Arch, Crystal Candelabras, Silk Linens, Ambient Uplights"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Description</label>
                <textarea
                  rows={2}
                  value={decorDescription}
                  onChange={(e) => setDecorDescription(e.target.value)}
                  placeholder="Atmosphere, color palette, floral varieties..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddDecor(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-brand-600 hover:bg-brand-500 shadow-md"
                >
                  Save Theme Package
                </button>
              </div>
            </form>
          )}

          {/* Decor Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {decorations.map((d) => (
              <div
                key={d.id}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm flex flex-col justify-between"
              >
                <div className="relative h-40 w-full bg-slate-800">
                  <img src={d.image} alt={d.title} className="w-full h-full object-cover" />
                  <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-full bg-slate-950/80 text-[10px] font-bold text-brand-300">
                    {d.category}
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">{d.title}</h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">{d.description}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400">Baseline</span>
                      <p className="text-xs font-bold text-slate-900 dark:text-white">
                        {formatCurrency(d.baselinePrice)}
                      </p>
                    </div>

                    <button
                      onClick={() => handleDeleteDecor(d.id, d.title)}
                      className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors"
                      title="Delete Theme"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ----------------- TAB 3: BOOKING REQUESTS ----------------- */}
      {activeTab === "bookings" && (
        <div className="space-y-6 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Customer Booking Requests
              </h2>
              <p className="text-xs text-slate-500">
                Review submitted requests from clients and approve or reject with real-time status toggles.
              </p>
            </div>

            {/* Filter controls */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search customer, ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:outline-none"
                />
              </div>

              <select
                value={bookingFilter}
                onChange={(e) => setBookingFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:outline-none font-medium"
              >
                <option value="all">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>

          {/* Bookings Structured Table */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase tracking-wider font-semibold text-[11px]">
                  <tr>
                    <th className="py-3.5 px-4">Booking Ref</th>
                    <th className="py-3.5 px-4">Client Details</th>
                    <th className="py-3.5 px-4">Date & Schedule</th>
                    <th className="py-3.5 px-4">Venue & Decor</th>
                    <th className="py-3.5 px-4">Guests</th>
                    <th className="py-3.5 px-4">Total Quote</th>
                    <th className="py-3.5 px-4">Status</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {filteredBookings.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-400">
                        No booking requests found matching filters.
                      </td>
                    </tr>
                  ) : (
                    filteredBookings.map((b) => {
                      const matchedVenue = venues.find((v) => v.id === b.venueId);
                      const matchedDecor = decorations.find((d) => d.id === b.decorationId);

                      return (
                        <tr
                          key={b.id}
                          className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors"
                        >
                          {/* Reference */}
                          <td className="py-3.5 px-4 font-mono font-bold text-brand-600 dark:text-brand-400">
                            {b.id}
                          </td>

                          {/* Client */}
                          <td className="py-3.5 px-4">
                            <p className="font-bold text-slate-900 dark:text-white leading-tight">
                              {b.customerName}
                            </p>
                            <p className="text-[11px] text-slate-400 mt-0.5">{b.customerEmail}</p>
                            {b.customerPhone && (
                              <p className="text-[10px] text-slate-500">{b.customerPhone}</p>
                            )}
                          </td>

                          {/* Date */}
                          <td className="py-3.5 px-4">
                            <p className="font-medium text-slate-800 dark:text-slate-200">
                              {formatDate(b.date)}
                            </p>
                            <p className="text-[11px] text-slate-400">
                              {b.time} ({b.durationHours} hrs)
                            </p>
                          </td>

                          {/* Venue & Decor */}
                          <td className="py-3.5 px-4">
                            <p className="font-semibold text-slate-900 dark:text-white truncate max-w-[140px]">
                              {matchedVenue?.title || "Custom Venue"}
                            </p>
                            <p className="text-[11px] text-brand-600 dark:text-brand-400 truncate max-w-[140px]">
                              {matchedDecor?.title || "Standard Styling"}
                            </p>
                          </td>

                          {/* Guests */}
                          <td className="py-3.5 px-4 font-semibold text-slate-700 dark:text-slate-300">
                            {b.guestCount}
                          </td>

                          {/* Total */}
                          <td className="py-3.5 px-4 font-extrabold text-slate-900 dark:text-white">
                            {formatCurrency(b.totalBudget)}
                          </td>

                          {/* Status Badge */}
                          <td className="py-3.5 px-4">
                            <span
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider ${
                                b.status === "approved"
                                  ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20"
                                  : b.status === "rejected"
                                  ? "bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20"
                                  : "bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20"
                              }`}
                            >
                              {b.status === "approved" && <CheckCircle2 className="w-3 h-3" />}
                              {b.status === "rejected" && <XCircle className="w-3 h-3" />}
                              {b.status === "pending" && <Clock className="w-3 h-3" />}
                              <span>{b.status}</span>
                            </span>
                          </td>

                          {/* Actions */}
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {b.status !== "approved" && (
                                <button
                                  onClick={() => handleStatusChange(b.id, "approved")}
                                  className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold shadow-sm"
                                  title="Approve Booking"
                                >
                                  Approve
                                </button>
                              )}
                              {b.status !== "rejected" && (
                                <button
                                  onClick={() => handleStatusChange(b.id, "rejected")}
                                  className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold shadow-sm"
                                  title="Reject Booking"
                                >
                                  Reject
                                </button>
                              )}
                              <button
                                onClick={() => handleDeleteBooking(b.id)}
                                className="p-1 text-slate-400 hover:text-rose-500 transition-colors"
                                title="Delete Record"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
