import React from "react";
import Link from "next/link";
import BrandLogo from "./BrandLogo";
import { Heart, Shield, Award, CalendarDays, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Info */}
          <div className="md:col-span-1 space-y-3">
            <BrandLogo size="md" showTagline={false} />
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              The premier intelligent platform for architectural event crafting, discovering verified venues, and designing bespoke themes with transparent real-time pricing.
            </p>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
              Explore
            </h4>
            <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
              <li>
                <Link href="/plan-event" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Plan Your Event
                </Link>
              </li>
              <li>
                <Link href="/admin" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Host & Admin Dashboard
                </Link>
              </li>
              <li>
                <Link href="/login" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Client & Host Login
                </Link>
              </li>
            </ul>
          </div>

          {/* Features */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
              EventCraft Features
            </h4>
            <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
              <li className="flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-brand-500" />
                <span>Verified Handpicked Venues</span>
              </li>
              <li className="flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-brand-500" />
                <span>Bespoke Styling Designers</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CalendarDays className="w-3.5 h-3.5 text-brand-500" />
                <span>Live Instant Cost Engine</span>
              </li>
            </ul>
          </div>

          {/* Contact & Support */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
              Direct Contact
            </h4>
            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
              <p className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-brand-500" />
                <span>concierge@eventcraft.io</span>
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-500">
                24/7 Dedicated Event Specialist Support
              </p>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-slate-200/60 dark:border-slate-800/60 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 dark:text-slate-400 gap-4">
          <p>© {new Date().getFullYear()} EventCraft Technologies Inc. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Engineered with <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" /> for unforgettable moments.
          </p>
        </div>
      </div>
    </footer>
  );
}
