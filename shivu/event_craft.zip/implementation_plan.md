# Implementation Plan - Full-Stack Event Manager Next.js Application

## 1. Overview & Technology Stack
An end-to-end interactive Event Management and Planning platform built with **Next.js (App Router)**, **TypeScript**, **Tailwind CSS**, and **Lucide-react** icons. The application caters to two key user roles: **Clients / Event Planners** (who configure events, select venues, customize decor, and submit bookings) and **Event Hosts / Administrators** (who manage venues, decoration packages, and review/approve incoming booking requests).

### Tech Stack:
- **Framework**: Next.js 15+ (App Router)
- **Language**: TypeScript (strict types, interfaces for models)
- **Styling**: Tailwind CSS with custom theme variables, dark mode support (`class` strategy), glassmorphism effects, and responsive layout
- **Icons**: `lucide-react`
- **State Management & Persistence**: React Context (`AuthContext`), LocalStorage with unified service layer (`lib/storage.ts`) and reactive event dispatching for cross-tab and component synchronization
- **Notifications**: Toast notification feedback system for logins, role switching, booking submissions, and admin actions

---

## 2. Modular Folder Structure
```
c:\Users\Dell\Downloads\New folder\
├── app/
│   ├── globals.css              # Tailwind base, dark mode styling & custom components
│   ├── layout.tsx               # Root layout with ThemeProvider, AuthProvider, Navbar & Toast
│   ├── page.tsx                 # Phase 1: Visually striking Hero landing page with CTAs
│   ├── login/
│   │   └── page.tsx             # Phase 2: Tabbed Auth (Login/Register, Role selection, Quick switch)
│   ├── plan-event/
│   │   └── page.tsx             # Phase 4: 5-Step Event Planner Wizard & Sticky Cost Calculator
│   └── admin/
│       └── page.tsx             # Phase 5: Host/Admin Dashboard with authorization guard
├── components/
│   ├── Navbar.tsx               # Phase 1: Navigation bar with dark/light mode toggle & auth state
│   ├── ThemeProvider.tsx        # Dark/light mode context and html class manager
│   ├── Toast.tsx                # Toast notification provider and hook
│   └── Footer.tsx               # Application footer
├── lib/
│   ├── authContext.tsx          # Phase 2: Auth context, user state, roles, quick demo accounts
│   ├── storage.ts               # Phase 3: LocalStorage persistence service for venues, decor, bookings
│   └── utils.ts                 # Formatting helpers (currency, date, class merger)
├── data/
│   └── mockData.ts              # Phase 3: Pre-loaded 6+ diverse venues & 6+ decoration themes
├── types/
│   └── index.ts                 # Phase 3: Full TypeScript definitions for Venues, Decor, Bookings, Users
├── public/                      # Static assets
├── package.json                 # Dependencies and scripts
├── tsconfig.json                # TypeScript configuration
├── tailwind.config.ts           # Tailwind CSS configuration
├── postcss.config.mjs           # PostCSS setup
└── next.config.ts               # Next.js configuration
```

---

## 3. Phase-by-Phase Execution Plan

### Phase 1: Next.js Foundation, Theming & Hero Landing
1. **Initialize Project Files**:
   - Create `package.json` with Next.js, React, React-DOM, TypeScript, Tailwind CSS, Lucide React, and essential utility libraries.
   - Setup `tsconfig.json`, `tailwind.config.ts`, `postcss.config.mjs`, and `next.config.ts`.
   - Run `npm install` in standard sandbox.
2. **Global Styling & Dark Mode**:
   - Configure Tailwind dark mode with `class` strategy.
   - Build `components/ThemeProvider.tsx` to persist and toggle dark/light theme seamlessly without flash of unstyled content.
3. **Global Navigation Bar (`components/Navbar.tsx`)**:
   - Navigation links: Home (`/`), Plan Event (`/plan-event`), Admin Portal (`/admin`).
   - Dark/Light mode toggle switch with sun/moon icons.
   - Dynamic user pill showing logged-in name, role badge ("Host" or "Client"), and Login/Register or Logout actions.
   - Responsive mobile drawer navigation.
4. **Hero Landing Page (`app/page.tsx`)**:
   - Premium headline with gradient text, badges, and background glow effects.
   - Primary Call-To-Action buttons: **"Start Planning"** (routes to `/plan-event`) and **"Become a Host"** (routes to `/login` or `/admin`).
   - Value proposition grid (Curated Venues, Bespoke Themes, Live Pricing Calculator, Instant Booking).
   - Showcase gallery of featured venues with dynamic pricing badges.
   - Client reviews and trust metrics counter.

---

### Phase 2: Modern Authentication Module
1. **Authentication Context (`lib/authContext.tsx`)**:
   - State: `currentUser: User | null`, `isAuthenticated: boolean`, `role: 'host' | 'client' | 'guest'`.
   - Methods: `login()`, `register()`, `logout()`, `quickLogin(role)`.
   - Persistence in `localStorage` (`event_auth_user`).
   - Integrated toast notification trigger on auth events.
2. **Authentication Page (`app/login/page.tsx`)**:
   - Animated tab switcher between "Login" and "Create Account".
   - Role Selection for Registration:
     - **Event Host**: List properties, manage packages, approve booking requests.
     - **Client / Event Planner**: Plan events, customize themes, request bookings.
   - Form fields with real-time validation:
     - Full Name, Email address, Password, Phone Number.
   - Development Fast-Switch Bar:
     - Quick buttons: **"Login as Client (Sarah Jenkins)"** and **"Login as Host (Marcus Vance)"**.
     - Provides zero-friction testing during reviews.

---

### Phase 3: Data Foundation & Local Storage Service
1. **Data Models (`types/index.ts`)**:
   - `Venue`: `id`, `title`, `image`, `capacity`, `pricePerHour`, `location`, `description`, `tags`, `rating`.
   - `Decoration`: `id`, `title`, `image`, `category`, `baselinePrice`, `description`, `includedItems`.
   - `AddOnService`: `id`, `name`, `price`, `description`, `icon`.
   - `Booking`: `id`, `userId`, `customerName`, `customerEmail`, `customerPhone`, `venueId`, `decorationId`, `guestCount`, `date`, `time`, `durationHours`, `addOns`, `totalBudget`, `status: 'pending' | 'approved' | 'rejected'`, `createdAt`, `notes`.
2. **Mock Dataset (`data/mockData.ts`)**:
   - 6+ High-end venues:
     - Grand Imperial Ballroom (Cap: 500, $450/hr)
     - Open-Air Botanical Garden (Cap: 250, $280/hr)
     - Azure Beachfront Lawn (Cap: 350, $380/hr)
     - The Glass Penthouse & Terrace (Cap: 150, $320/hr)
     - Vintage Industrial Foundry (Cap: 300, $240/hr)
     - Mountain Crest Meadow Pavilion (Cap: 200, $290/hr)
   - 6+ Diverse decoration packages:
     - Royal Gold & Crystal Elegance ($1,800)
     - Vintage Floral Romance ($1,250)
     - Minimalist Neon Cyber Chic ($950)
     - Eco-Friendly Botanical Greenery ($1,100)
     - Celestial Midnight Starlight ($1,400)
     - Sun-Drenched Bohemian Sunset ($1,050)
   - Add-on services: Gourmet Catering, DJ & Sound System, 4K Photography & Drone, Lighting & FX.
3. **Local Storage Service (`lib/storage.ts`)**:
   - Initializer that bootstraps `mockData` if keys do not exist.
   - CRUD functions for Venues, Decorations, and Bookings.
   - Custom `window.dispatchEvent` mechanism ensuring real-time cross-component reactivity.

---

### Phase 4: Interactive Step-by-Step Event Planner Wizard
1. **Wizard Layout (`app/plan-event/page.tsx`)**:
   - Left side: 5-step interactive wizard with step progress indicators.
   - Right side: Sticky Dynamic Cost Calculator updating in real time.
2. **Steps Breakdown**:
   - **Step 1: Event Details**: Date picker, Start Time, Duration (hours), Headcount slider (10 to 800) with quick chips.
   - **Step 2: Venue Selection**: Search, capacity filter, and price filter. Capacity check alert if guest headcount exceeds venue capacity.
   - **Step 3: Decoration & Theme**: Category filter, preview cards with image, price, and description.
   - **Step 4: Add-On Services**: Multi-select cards for Catering ($45/person or flat package), Sound & DJ, Photography, Lighting.
   - **Step 5: Summary & Confirmation**: Complete itemized breakdown, customer details verification, special notes.
3. **Dynamic Cost Calculator Sidebar**:
   - Venue Cost = Price/Hour × Hours.
   - Decoration Baseline Package.
   - Add-ons Breakdown.
   - Service Charge & Tax Calculation.
   - Total Estimated Budget with real-time recalculation.
4. **Booking Submission**:
   - Persists booking to `storage.ts`.
   - Transitions to an engaging Celebration Confirmation screen with Reference ID, details recap, and links to Admin Portal or New Event.

---

### Phase 5: Host / Admin Dashboard
1. **Host Guard (`app/admin/page.tsx`)**:
   - Checks if user role is `'host'`.
   - If unauthenticated or client: Shows an alert screen with an instant "Switch to Host Role" button and "Login" link.
2. **Dashboard Overview Metrics**:
   - Total Gross Inquiries, Total Venues, Total Decor Packages, Pending Requests count.
3. **Management Tabs**:
   - **Tab 1: Manage Venues**:
     - Form to add new venue (Title, Image URL, Capacity, Price/hr, Location, Description, Tags).
     - Responsive grid of venues with Edit and Delete options.
   - **Tab 2: Manage Decorations**:
     - Form to create new decoration package (Title, Image URL, Category, Price, Description).
     - List/grid with Delete and Edit capabilities.
   - **Tab 3: Booking Requests**:
     - Full data table displaying all client bookings.
     - Status badges: Pending (yellow), Approved (green), Rejected (red).
     - 1-click status update buttons.
4. **Instant Sync**:
   - Host additions immediately update localStorage, reflecting in the Event Planner Wizard without page reloads.

---

## 4. Verification & Testing Strategy
- Verify builds and compilation via Next.js compiler.
- Test authentication flows (Login, Register, Logout, Quick Host/Client switch).
- Test wizard flow end-to-end: Set date/guests -> Pick venue -> Pick theme -> Pick add-ons -> View live price sidebar -> Submit booking.
- Verify Admin dashboard: Add a custom venue and decoration -> Verify they immediately appear in the Planner Wizard -> Approve a booking and verify status update.
