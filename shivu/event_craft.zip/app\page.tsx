"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Building2,
  Palette,
  Calculator,
  Users,
  MapPin,
  Star,
  CheckCircle2,
  CalendarCheck,
  Crown,
  Wand2,
  Layers,
} from "lucide-react";
import { getVenues, getDecorations } from "@/lib/storage";
import { Venue, Decoration } from "@/types";
import { formatCurrency } from "@/lib/utils";

export default function HomePage() {
  const [featuredVenues, setFeaturedVenues] = useState<Venue[]>([]);
  const [featuredDecor, setFeaturedDecor] = useState<Decoration[]>([]);

  useEffect(() => {
    setFeaturedVenues(getVenues().slice(0, 3));
    setFeaturedDecor(getDecorations().slice(0, 3));
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      {/* ----------------- HERO SECTION ----------------- */}
      <section className="relative overflow-hidden pt-12 pb-24 lg:pt-20 lg:pb-32 bg-gradient-to-b from-brand-950/15 via-slate-50 to-white dark:from-brand-950/40 dark:via-slate-950 dark:to-slate-950">
        {/* Background ambient glowing orbs */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[450px] bg-gradient-to-tr from-brand-600/20 via-indigo-600/15 to-amber-500/20 rounded-full blur-3xl pointer-events-none -z-10" />
        <div className="absolute top-10 right-10 w-72 h-72 bg-amber-500/10 rounded-full blur-2xl pointer-events-none -z-10" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Eyebrow badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-100/80 dark:bg-brand-950/80 border border-brand-300 dark:border-brand-800 text-brand-800 dark:text-brand-300 text-xs sm:text-sm font-semibold mb-8 shadow-sm">
            <Wand2 className="w-4 h-4 text-amber-500 dark:text-amber-400" />
            <span>Welcome to EventCraft • Next-Gen Architectural Event Platform</span>
          </div>

          {/* Main Title */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-slate-900 dark:text-white max-w-5xl mx-auto leading-[1.12]">
            Craft Extraordinary Gatherings With{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-brand-600 via-indigo-600 to-amber-500 dark:from-brand-400 dark:via-purple-300 dark:to-amber-300">
              EventCraft
            </span>
          </h1>

          {/* Subtitle */}
          <p className="mt-6 text-lg sm:text-xl text-slate-600 dark:text-slate-300 max-w-3xl mx-auto leading-relaxed">
            From luxury ballrooms to sunset ocean bluffs, architect your celebration with verified venues, designer styling packages, and an instant live budget engine.
          </p>

          {/* Primary Action Buttons */}
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/plan-event"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl text-base font-bold text-white bg-gradient-to-r from-brand-600 via-indigo-600 to-purple-600 hover:from-brand-500 hover:to-purple-500 shadow-xl shadow-brand-600/30 hover:shadow-brand-600/50 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200"
            >
              <Sparkles className="w-5 h-5 text-amber-300" />
              <span>Start Planning with EventCraft</span>
              <ArrowRight className="w-5 h-5 ml-1" />
            </Link>

            <Link
              href="/login?role=host"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl text-base font-bold text-slate-800 dark:text-slate-100 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 shadow-sm hover:scale-[1.02] active:scale-[0.98] transition-all duration-200"
            >
              <Building2 className="w-5 h-5 text-amber-500" />
              <span>Become an EventCraft Host</span>
            </Link>
          </div>

          {/* Trust stats counter */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto pt-8 border-t border-slate-200/80 dark:border-slate-800/80">
            <div className="p-4 rounded-2xl bg-white/50 dark:bg-slate-900/40 border border-slate-200/60 dark:border-slate-800/60">
              <p className="text-3xl font-extrabold text-slate-900 dark:text-white">1,500+</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">Events Crafted</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/50 dark:bg-slate-900/40 border border-slate-200/60 dark:border-slate-800/60">
              <p className="text-3xl font-extrabold text-amber-500 dark:text-amber-400">4.95 ★</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">Client Satisfaction</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/50 dark:bg-slate-900/40 border border-slate-200/60 dark:border-slate-800/60">
              <p className="text-3xl font-extrabold text-slate-900 dark:text-white">50+</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">Verified Venues</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/50 dark:bg-slate-900/40 border border-slate-200/60 dark:border-slate-800/60">
              <p className="text-3xl font-extrabold text-emerald-500 dark:text-emerald-400">100%</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">Cost Transparency</p>
            </div>
          </div>
        </div>
      </section>

      {/* ----------------- HOW IT WORKS ----------------- */}
      <section className="py-20 bg-slate-100/60 dark:bg-slate-900/40 border-y border-slate-200/80 dark:border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-xs uppercase font-extrabold tracking-widest text-brand-600 dark:text-brand-400 mb-2">
              The EventCraft Method
            </h2>
            <h3 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Design Your Venue Experience Step-by-Step
            </h3>
            <p className="mt-3 text-slate-600 dark:text-slate-400 text-sm sm:text-base">
              Say goodbye to guesswork and delayed quotes. Configure every architectural detail with complete budget visibility.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm relative hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-4 font-black text-lg">
                1
              </div>
              <h4 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                Set Event Parameters
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Choose targeted date, hours duration, and guest capacity slider.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm relative hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-xl bg-brand-500/10 text-brand-600 dark:text-brand-400 flex items-center justify-center mb-4 font-black text-lg">
                2
              </div>
              <h4 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                Filter & Select Venue
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Browse pre-vetted grand ballrooms, botanical conservatories, and beach lawns tailored to your headcount.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm relative hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center mb-4 font-black text-lg">
                3
              </div>
              <h4 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                Curate Decor & Add-Ons
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Pick bespoke theme packages (Royal Gold, Vintage Flora) and toggle catering, DJ, and 4K photo options.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm relative hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-4 font-black text-lg">
                4
              </div>
              <h4 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                Instant Confirmation
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Watch the live sticky cost calculator update and lock in your reservation with one click.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ----------------- FEATURED VENUES SHOWCASE ----------------- */}
      <section className="py-20 bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
            <div>
              <span className="text-xs uppercase font-extrabold tracking-wider text-amber-500">
                Curated Architecture
              </span>
              <h3 className="text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
                Featured Exclusive Venues
              </h3>
            </div>
            <Link
              href="/plan-event"
              className="mt-4 md:mt-0 inline-flex items-center gap-1.5 text-sm font-bold text-brand-600 dark:text-brand-400 hover:underline"
            >
              <span>Explore all venues in planner</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredVenues.map((venue) => (
              <div
                key={venue.id}
                className="group rounded-3xl overflow-hidden bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col"
              >
                <div className="relative h-56 w-full overflow-hidden bg-slate-800">
                  <img
                    src={venue.image}
                    alt={venue.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-slate-950/80 backdrop-blur-md text-white text-xs font-bold flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    <span>{venue.rating || 4.9}</span>
                  </div>
                  <div className="absolute bottom-3 left-3 px-3 py-1 rounded-xl bg-white/90 dark:bg-slate-950/90 backdrop-blur-md text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Cap: Up to {venue.capacity} guests
                  </div>
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1.5">
                      <MapPin className="w-3.5 h-3.5 text-brand-500 shrink-0" />
                      <span className="truncate">{venue.location}</span>
                    </div>
                    <h4 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                      {venue.title}
                    </h4>
                    <p className="mt-2 text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                      {venue.description}
                    </p>
                  </div>

                  <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-500 dark:text-slate-400">Starting at</span>
                      <p className="text-lg font-extrabold text-slate-900 dark:text-white">
                        {formatCurrency(venue.pricePerHour)}
                        <span className="text-xs font-normal text-slate-500"> / hr</span>
                      </p>
                    </div>
                    <Link
                      href={`/plan-event?venueId=${venue.id}`}
                      className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-bold shadow-sm transition-colors"
                    >
                      Craft Event Here
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ----------------- HOST CTA BANNER ----------------- */}
      <section className="py-16 bg-gradient-to-r from-brand-950 via-slate-950 to-indigo-950 text-white relative overflow-hidden border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="max-w-2xl text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-300 text-xs font-bold mb-4">
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>For Venue Owners & Event Designers</span>
            </div>
            <h3 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
              Have an extraordinary space or styling collection?
            </h3>
            <p className="mt-3 text-slate-300 text-sm sm:text-base leading-relaxed">
              Join the EventCraft partner network. Publish your spaces, create custom decor packages, approve client reservations, and earn with guaranteed deposit transparency.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
            <Link
              href="/login?role=host"
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl text-sm font-bold bg-white text-slate-900 hover:bg-slate-100 shadow-lg hover:scale-105 transition-all text-center"
            >
              <Building2 className="w-4 h-4 text-amber-500" />
              <span>EventCraft Host Access</span>
            </Link>
            <Link
              href="/admin"
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl text-sm font-bold bg-brand-900/80 hover:bg-brand-800/80 border border-brand-500/30 text-white transition-all text-center"
            >
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>Preview Admin Portal</span>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
