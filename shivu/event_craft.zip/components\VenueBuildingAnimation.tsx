"use client";

import React, { useState, useEffect } from "react";
import {
  Sparkles,
  Hammer,
  Layers,
  Wand2,
  CheckCircle2,
  Volume2,
  VolumeX,
  RotateCcw,
  PartyPopper,
  Flame,
} from "lucide-react";

const CRAFT_STEPS = [
  {
    step: 1,
    title: "1. Laying Acoustic Hardwood Stage",
    description: "Laser-leveled foundation & warm mahogany parquet.",
    color: "#f59e0b",
  },
  {
    step: 2,
    title: "2. Erecting Glass Pavilion Trusses",
    description: "Panoramic steel arches & 24ft skylight frames.",
    color: "#6366f1",
  },
  {
    step: 3,
    title: "3. Lowering 24k Crystal Chandelier",
    description: "Swarovski drops descending with warm ambient glow.",
    color: "#ec4899",
  },
  {
    step: 4,
    title: "4. Styling Botanical Floral Archways",
    description: "Fresh garden roses, eucalyptus & fairy canopies.",
    color: "#10b981",
  },
  {
    step: 5,
    title: "5. Stage Ready for Showtime!",
    description: "Synchronized moving spotlights & celebration confetti.",
    color: "#8b5cf6",
  },
];

export default function VenueBuildingAnimation() {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(true);

  // Auto-progress through the building sequence
  useEffect(() => {
    if (!isAutoPlaying) return;
    const timer = setInterval(() => {
      setActiveStep((prev) => (prev >= 5 ? 1 : prev + 1));
    }, 3800);
    return () => clearInterval(timer);
  }, [isAutoPlaying]);

  return (
    <div className="relative w-full h-full min-h-[580px] rounded-3xl overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-brand-950 border border-slate-800 p-6 flex flex-col justify-between shadow-2xl select-none">
      {/* Background ambient stage lights */}
      <div className="absolute top-0 left-1/4 w-80 h-80 bg-brand-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:20px_20px] opacity-25" />

      {/* Top Header & Construction Step Bar */}
      <div className="relative z-10 flex items-center justify-between">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-brand-500/30 backdrop-blur-md">
          <Wand2 className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
          <span className="text-[11px] font-bold text-slate-200">
            EventCraft Live Venue Builder Engine
          </span>
        </div>

        <button
          onClick={() => setActiveStep(1)}
          title="Restart Construction Sequence"
          className="flex items-center gap-1.5 px-3 py-1 rounded-xl text-[11px] font-semibold bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
        >
          <RotateCcw className="w-3 h-3 text-amber-400" />
          <span>Replay Build</span>
        </button>
      </div>

      {/* ---------------- MAIN ISOMETRIC VENUE CRAFTING CANVAS ---------------- */}
      <div className="relative z-10 flex-1 flex items-center justify-center my-4 overflow-hidden min-h-[360px]">
        {/* Moving Spotlights from Top Left & Top Right */}
        <div
          className={`absolute -top-10 left-12 w-32 h-96 bg-gradient-to-b from-amber-400/40 via-amber-300/10 to-transparent blur-md transform origin-top rotate-[25deg] transition-all duration-1000 pointer-events-none ${
            activeStep >= 3 ? "opacity-100" : "opacity-0"
          }`}
          style={{
            animation: activeStep >= 3 ? "sweepLeft 4s ease-in-out infinite alternate" : "none",
          }}
        />
        <div
          className={`absolute -top-10 right-12 w-32 h-96 bg-gradient-to-b from-indigo-400/40 via-purple-300/10 to-transparent blur-md transform origin-top -rotate-[25deg] transition-all duration-1000 pointer-events-none ${
            activeStep >= 3 ? "opacity-100" : "opacity-0"
          }`}
          style={{
            animation: activeStep >= 3 ? "sweepRight 4s ease-in-out infinite alternate" : "none",
          }}
        />

        {/* Central Stage Structure SVG */}
        <div className="relative w-full max-w-[460px] h-[340px] flex items-center justify-center">
          <svg
            viewBox="0 0 500 380"
            className="w-full h-full drop-shadow-2xl overflow-visible"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* 1. BLUEPRINT GRID & GROUNDWORK */}
            <g className="transition-opacity duration-700">
              {/* Isometric grid tiles */}
              <path
                d="M250 150 L430 240 L250 330 L70 240 Z"
                fill="url(#foundationGrad)"
                stroke="#475569"
                strokeWidth="1.5"
                strokeDasharray="4 4"
              />
              <path
                d="M250 170 L400 245 L250 320 L100 245 Z"
                fill="#1e1b4b"
                fillOpacity="0.4"
                stroke="#6366f1"
                strokeWidth="1"
              />
            </g>

            {/* 2. STAGE PLATFORM (STEP 1+) */}
            <g
              className={`transition-all duration-700 ${
                activeStep >= 1
                  ? "opacity-100 transform translate-y-0"
                  : "opacity-0 transform translate-y-8"
              }`}
            >
              {/* Stage Base Thickness */}
              <path
                d="M70 240 L250 330 L430 240 L430 258 L250 348 L70 258 Z"
                fill="#0f172a"
                stroke="#64748b"
                strokeWidth="1.5"
              />
              {/* Hardwood Decking Top Surface */}
              <path
                d="M70 240 L250 150 L430 240 L250 330 Z"
                fill="url(#hardwoodDeck)"
                stroke="#d97706"
                strokeWidth="2"
              />
              {/* Decking Planks lines */}
              <line x1="115" y1="217" x2="295" y2="307" stroke="#78350f" strokeWidth="1" strokeOpacity="0.6" />
              <line x1="160" y1="195" x2="340" y2="285" stroke="#78350f" strokeWidth="1" strokeOpacity="0.6" />
              <line x1="205" y1="172" x2="385" y2="262" stroke="#78350f" strokeWidth="1" strokeOpacity="0.6" />

              {/* Stage Front Steps */}
              <path
                d="M210 310 L250 330 L290 310 L290 325 L250 345 L210 325 Z"
                fill="#d97706"
                stroke="#b45309"
              />
            </g>

            {/* 3. ARCHITECTURAL TRUSSES & PILLARS (STEP 2+) */}
            <g
              className={`transition-all duration-700 ${
                activeStep >= 2
                  ? "opacity-100 transform translate-y-0 scale-100"
                  : "opacity-0 transform translate-y-12 scale-95"
              }`}
            >
              {/* Left Pillar */}
              <rect x="110" y="80" width="16" height="145" rx="3" fill="url(#pillarGrad)" stroke="#cbd5e1" strokeWidth="1" />
              <path d="M104 80 L132 80 L126 90 L110 90 Z" fill="#f8fafc" />
              <path d="M104 225 L132 225 L126 215 L110 215 Z" fill="#f8fafc" />

              {/* Right Pillar */}
              <rect x="374" y="80" width="16" height="145" rx="3" fill="url(#pillarGrad)" stroke="#cbd5e1" strokeWidth="1" />
              <path d="M368 80 L396 80 L390 90 L374 90 Z" fill="#f8fafc" />
              <path d="M368 225 L396 225 L390 215 L374 215 Z" fill="#f8fafc" />

              {/* Center Rear Pillars */}
              <rect x="242" y="30" width="16" height="130" rx="2" fill="url(#pillarGrad)" stroke="#94a3b8" strokeWidth="1" />

              {/* Grand Cathedral Arch Truss */}
              <path
                d="M118 80 Q 250 -10 382 80"
                stroke="url(#trussGrad)"
                strokeWidth="5"
                strokeLinecap="round"
                fill="none"
              />
              <path
                d="M118 90 Q 250 15 382 90"
                stroke="#94a3b8"
                strokeWidth="2"
                strokeLinecap="round"
                fill="none"
              />

              {/* Diagonal Cross Braces */}
              <line x1="160" y1="65" x2="190" y2="40" stroke="#64748b" strokeWidth="1.5" />
              <line x1="220" y1="28" x2="250" y2="10" stroke="#64748b" strokeWidth="1.5" />
              <line x1="280" y1="10" x2="310" y2="28" stroke="#64748b" strokeWidth="1.5" />
              <line x1="340" y1="40" x2="370" y2="65" stroke="#64748b" strokeWidth="1.5" />

              {/* Glass Canopy Subtle Sheen */}
              <path
                d="M118 80 Q 250 -10 382 80 L382 90 Q 250 15 118 90 Z"
                fill="url(#glassSheen)"
                opacity="0.35"
              />
            </g>

            {/* 4. CHANDELIER & LIGHTING RIG (STEP 3+) */}
            <g
              className={`transition-all duration-1000 ${
                activeStep >= 3
                  ? "opacity-100 transform translate-y-0"
                  : "opacity-0 transform -translate-y-16"
              }`}
            >
              {/* Golden suspension chain */}
              <line x1="250" y1="10" x2="250" y2="85" stroke="#fbbf24" strokeWidth="2" strokeDasharray="3 2" />

              {/* Chandelier Rings */}
              <ellipse cx="250" cy="88" rx="28" ry="8" fill="#78350f" stroke="#fbbf24" strokeWidth="2" />
              <ellipse cx="250" cy="98" rx="20" ry="6" fill="#78350f" stroke="#fbbf24" strokeWidth="1.5" />

              {/* Chandelier Glow Orb */}
              <circle cx="250" cy="98" r="45" fill="url(#chandelierGlow)" opacity="0.8" />

              {/* Crystal drops */}
              {[
                { x: 230, y: 92, len: 14 },
                { x: 240, y: 95, len: 18 },
                { x: 250, y: 96, len: 22 },
                { x: 260, y: 95, len: 18 },
                { x: 270, y: 92, len: 14 },
              ].map((c, i) => (
                <g key={i}>
                  <line x1={c.x} y1={c.y} x2={c.x} y2={c.y + c.len} stroke="#fef08a" strokeWidth="1.5" />
                  <circle cx={c.x} cy={c.y + c.len + 2} r="2.5" fill="#fef08a" />
                </g>
              ))}

              {/* Moving Head Lights on Floor Edge */}
              <circle cx="100" cy="245" r="7" fill="#334155" stroke="#38bdf8" strokeWidth="1.5" />
              <circle cx="400" cy="245" r="7" fill="#334155" stroke="#f59e0b" strokeWidth="1.5" />
            </g>

            {/* 5. FLORAL ARCHES & BOTANICAL GARLANDS (STEP 4+) */}
            <g
              className={`transition-all duration-700 ${
                activeStep >= 4
                  ? "opacity-100 transform scale-100"
                  : "opacity-0 transform scale-90"
              }`}
            >
              {/* Left Pillar Floral Vines */}
              <path
                d="M106 220 Q 115 160 108 120 Q 120 90 125 80"
                stroke="#15803d"
                strokeWidth="5"
                strokeLinecap="round"
                fill="none"
              />
              {/* Right Pillar Floral Vines */}
              <path
                d="M390 220 Q 380 160 388 120 Q 378 90 375 80"
                stroke="#15803d"
                strokeWidth="5"
                strokeLinecap="round"
                fill="none"
              />
              {/* Arch Floral Swag */}
              <path
                d="M125 80 Q 250 15 375 80"
                stroke="#16a34a"
                strokeWidth="6"
                strokeLinecap="round"
                fill="none"
              />

              {/* Blooming Floral Buds */}
              {[
                { cx: 110, cy: 190, r: 5, color: "#f43f5e" },
                { cx: 118, cy: 150, r: 6, color: "#fb7185" },
                { cx: 110, cy: 115, r: 5, color: "#fda4af" },
                { cx: 150, cy: 75, r: 6, color: "#f43f5e" },
                { cx: 200, cy: 45, r: 7, color: "#fb7185" },
                { cx: 250, cy: 30, r: 8, color: "#fff" }, // Centerpiece white rose
                { cx: 300, cy: 45, r: 7, color: "#fb7185" },
                { cx: 350, cy: 75, r: 6, color: "#f43f5e" },
                { cx: 386, cy: 115, r: 5, color: "#fda4af" },
                { cx: 378, cy: 150, r: 6, color: "#fb7185" },
                { cx: 386, cy: 190, r: 5, color: "#f43f5e" },
              ].map((b, idx) => (
                <circle
                  key={idx}
                  cx={b.cx}
                  cy={b.cy}
                  r={b.r}
                  fill={b.color}
                  stroke="#881337"
                  strokeWidth="0.8"
                />
              ))}

              {/* VIP Cocktail Table Setup on Stage */}
              <ellipse cx="250" cy="235" rx="18" ry="8" fill="#f8fafc" stroke="#cbd5e1" />
              <rect x="247" y="235" width="6" height="24" fill="#cbd5e1" />
              <ellipse cx="250" cy="259" rx="10" ry="4" fill="#64748b" />
              {/* Champagne bottle on table */}
              <rect x="248" y="222" width="4" height="12" rx="1" fill="#15803d" />
              <circle cx="250" cy="220" r="1.5" fill="#f59e0b" />
            </g>

            {/* 6. CARTOON EVENT PLANNER / CRAFT ARCHITECT CHARACTER */}
            <g
              className="transform transition-transform duration-500 hover:scale-105"
              style={{ transformOrigin: "60px 280px" }}
            >
              {/* Planner Shadow */}
              <ellipse cx="60" cy="305" rx="18" ry="6" fill="#020617" opacity="0.6" />

              {/* Shoes */}
              <rect x="52" y="295" width="8" height="10" rx="3" fill="#0f172a" />
              <rect x="62" y="295" width="8" height="10" rx="3" fill="#0f172a" />

              {/* Stylish Trousers */}
              <path d="M52 260 L54 296 L60 296 L62 275 L64 296 L70 296 L72 260 Z" fill="#1e293b" />

              {/* Blazer / Designer Coat */}
              <path
                d="M48 220 L76 220 L74 265 L50 265 Z"
                fill="url(#coatGrad)"
                stroke="#6366f1"
                strokeWidth="1"
              />

              {/* Arm holding Blueprint Clipboard */}
              <path d="M48 225 L38 245 L48 250" stroke="#f1f5f9" strokeWidth="4" strokeLinecap="round" />
              {/* Blueprint Clipboard */}
              <rect x="30" y="240" width="14" height="18" rx="2" fill="#3b82f6" stroke="#93c5fd" strokeWidth="1" transform="rotate(-15 30 240)" />
              <line x1="33" y1="246" x2="41" y2="244" stroke="#fff" strokeWidth="1" />
              <line x1="33" y1="250" x2="41" y2="248" stroke="#fff" strokeWidth="1" />

              {/* Arm holding Magic EventCraft Wand */}
              <path d="M74 225 L88 235 L96 220" stroke="#f1f5f9" strokeWidth="4" strokeLinecap="round" />
              {/* Magic Wand */}
              <line x1="92" y1="225" x2="108" y2="205" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round" />
              <circle cx="109" cy="204" r="3.5" fill="#f59e0b" className="animate-ping" />
              <polygon points="109,198 112,203 118,204 113,207 114,213 109,209 104,213 105,207 100,204 106,203" fill="#fbbf24" />

              {/* Head & Face */}
              <circle cx="62" cy="205" r="10" fill="#fed7aa" />
              {/* Happy smiling eyes & smile */}
              <circle cx="65" cy="203" r="1.2" fill="#0f172a" />
              <path d="M63 207 Q 66 210 68 207" stroke="#0f172a" strokeWidth="1" fill="none" />

              {/* Modern Event Designer Glasses */}
              <rect x="63" y="201" width="5" height="4" rx="1" fill="none" stroke="#6366f1" strokeWidth="0.8" />

              {/* Yellow Architectural Hard Hat / Beret */}
              <path d="M51 200 Q 62 188 73 200 Z" fill="#f59e0b" stroke="#d97706" strokeWidth="1.2" />
              <rect x="49" y="199" width="26" height="3" rx="1.5" fill="#f59e0b" />
            </g>

            {/* 7. SHOWTIME CONFETTI & MAGIC BURST (STEP 5) */}
            {activeStep === 5 && (
              <g className="animate-fade-in">
                {[
                  { cx: 180, cy: 90, color: "#ec4899", size: 3 },
                  { cx: 320, cy: 110, color: "#38bdf8", size: 4 },
                  { cx: 210, cy: 140, color: "#facc15", size: 3.5 },
                  { cx: 290, cy: 130, color: "#a855f7", size: 4 },
                  { cx: 150, cy: 180, color: "#34d399", size: 3 },
                  { cx: 360, cy: 170, color: "#fb7185", size: 3.5 },
                  { cx: 240, cy: 60, color: "#f59e0b", size: 4.5 },
                ].map((confetti, idx) => (
                  <rect
                    key={idx}
                    x={confetti.cx}
                    y={confetti.cy}
                    width={confetti.size}
                    height={confetti.size * 2}
                    rx="1"
                    fill={confetti.color}
                    transform={`rotate(${idx * 45} ${confetti.cx} ${confetti.cy})`}
                    className="animate-pulse"
                  />
                ))}
              </g>
            )}

            {/* SVG Gradients */}
            <defs>
              <linearGradient id="foundationGrad" x1="70" y1="240" x2="430" y2="240" gradientUnits="userSpaceOnUse">
                <stop stopColor="#0f172a" />
                <stop offset="0.5" stopColor="#1e1b4b" />
                <stop offset="1" stopColor="#0f172a" />
              </linearGradient>

              <linearGradient id="hardwoodDeck" x1="70" y1="240" x2="430" y2="240" gradientUnits="userSpaceOnUse">
                <stop stopColor="#b45309" />
                <stop offset="0.5" stopColor="#d97706" />
                <stop offset="1" stopColor="#92400e" />
              </linearGradient>

              <linearGradient id="pillarGrad" x1="0" y1="0" x2="1" y2="1">
                <stop stopColor="#f8fafc" />
                <stop offset="0.5" stopColor="#cbd5e1" />
                <stop offset="1" stopColor="#94a3b8" />
              </linearGradient>

              <linearGradient id="trussGrad" x1="118" y1="80" x2="382" y2="80" gradientUnits="userSpaceOnUse">
                <stop stopColor="#a855f7" />
                <stop offset="0.5" stopColor="#6366f1" />
                <stop offset="1" stopColor="#f59e0b" />
              </linearGradient>

              <linearGradient id="glassSheen" x1="118" y1="80" x2="382" y2="80" gradientUnits="userSpaceOnUse">
                <stop stopColor="#38bdf8" stopOpacity="0.8" />
                <stop offset="1" stopColor="#e0e7ff" stopOpacity="0.1" />
              </linearGradient>

              <radialGradient id="chandelierGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#fde047" stopOpacity="0.8" />
                <stop offset="40%" stopColor="#f59e0b" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#f59e0b" stopOpacity="0" />
              </radialGradient>

              <linearGradient id="coatGrad" x1="0" y1="0" x2="1" y2="1">
                <stop stopColor="#4338ca" />
                <stop offset="1" stopColor="#6d28d9" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>

      {/* Bottom Interactive Step Indicator & Description */}
      <div className="relative z-10 pt-4 border-t border-slate-800/80">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span
              className="w-2.5 h-2.5 rounded-full animate-ping"
              style={{ backgroundColor: CRAFT_STEPS[activeStep - 1].color }}
            />
            <h4 className="text-xs font-bold text-slate-100">
              {CRAFT_STEPS[activeStep - 1].title}
            </h4>
          </div>
          <span className="text-[10px] font-mono text-slate-400">
            Phase {activeStep} of 5
          </span>
        </div>

        <p className="text-[11px] text-slate-400 mb-3">
          {CRAFT_STEPS[activeStep - 1].description}
        </p>

        {/* Clickable Step Pills */}
        <div className="grid grid-cols-5 gap-1.5">
          {CRAFT_STEPS.map((s) => (
            <button
              key={s.step}
              onClick={() => {
                setActiveStep(s.step);
                setIsAutoPlaying(false);
              }}
              className={`py-1.5 px-1 rounded-lg text-[10px] font-bold transition-all text-center ${
                activeStep === s.step
                  ? "bg-brand-600 text-white shadow-md shadow-brand-500/30 scale-105"
                  : "bg-slate-900/90 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800"
              }`}
            >
              Step {s.step}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
